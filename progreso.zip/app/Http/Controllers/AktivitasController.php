<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AktivitasController extends Controller
{
  public function index()
  {
    $aktivitas = DB::select('select *, datediff(curdate(), tanggal) as day from aktivitas, tb_anggota
                      where aktivitas.nim = tb_anggota.nim
                      order by tanggal desc limit 10');

    return view('layout/aktivitas/aktivitas', ['aktivitas' => $aktivitas]);
  }

  public function full()
  {
    $aktivitas = DB::select('select *, datediff(curdate(), tanggal) as day from aktivitas, tb_anggota
                      where aktivitas.nim = tb_anggota.nim
                      order by tanggal desc');

    return view('layout/aktivitas/aktivitas', ['aktivitas' => $aktivitas]);
  }
}
