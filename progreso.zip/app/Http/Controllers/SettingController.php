<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\SimpleXmlElement;

class SettingController extends Controller
{
  public function manifesto()
  {
      return view('layout/setting/manifesto');
  }

  public function getContent()
  {
      $content = file_get_contents('http://rss.leparisien.fr/leparisien/rss/paris-75.xml');
      $flux = new SimpleXmlElement($content);

      return View::make('layout/setting/content', compact('flux'));
  }
}
