<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class KameradController extends Controller
{

  public function index()
  {
    $totem = 'aktif';
    $kamerads = DB::table('tb_anggota')
                    ->join('prodi', 'tb_anggota.kode_prodi', '=', 'prodi.kode_prodi')
                    ->where('status', '0')
                    ->orderBy('angkatan', 'asc')
                    ->get();

    $widprodi = DB::select('select prodi, count(*) as jumlah from prodi, tb_anggota
                          where prodi.kode_prodi = tb_anggota.kode_prodi and status = :status
                          group by prodi	order by jumlah desc', ['status' => '0']);

    $widangkatan = DB::select('select angkatan, count(*) as jumlah from tb_anggota
                          where status = :status
                          group by angkatan	order by angkatan desc', ['status' => '0']);

    $widstatus = DB::select('select status, count(*) as jumlah from tb_anggota
                          group by status desc');

    // $needs = DB::table('tb_anggota')
    //                         ->join('tb_konten', 'tb_anggota.nim', '=', 'tb_konten.redaktur')
    //                         ->select(DB::raw('count(*) as jumlah, panggilan, image, nim'))
    //                         ->where('status', '0')
    //                         ->orderBy('jumlah', 'desc')
    //                         ->groupBy('panggilan')
    //                         ->get();
                            // dd($needs);

    return view('layout/kamerad/kamerad', ['totem' => $totem, 'kamerads' => $kamerads, 'widprodi' => $widprodi, 'widangkatan' => $widangkatan, 'widstatus' => $widstatus]);
  }

  public function post()
  {
    $totem = 'post';
    $kamerads = DB::table('tb_anggota')
                    ->join('prodi', 'tb_anggota.kode_prodi', '=', 'prodi.kode_prodi')
                    ->where('status', '1')
                    ->orderBy('angkatan', 'asc')
                    ->get();

    $widprodi = DB::select('select prodi, count(*) as jumlah from prodi, tb_anggota
                          where prodi.kode_prodi = tb_anggota.kode_prodi and status = :status
                          group by prodi	order by jumlah desc', ['status' => '1']);

    $widangkatan = DB::select('select angkatan, count(*) as jumlah from tb_anggota
                          where status = :status
                          group by angkatan	order by angkatan desc', ['status' => '1']);

    $widstatus = DB::select('select status, count(*) as jumlah from tb_anggota
                          group by status desc');

    // $needs = DB::table('tb_anggota')
    //                         ->join('tb_konten', 'tb_anggota.nim', '=', 'tb_konten.redaktur')
    //                         ->select(DB::raw('count(*) as jumlah, panggilan, image, nim'))
    //                         ->where('status', '0')
    //                         ->orderBy('jumlah', 'desc')
    //                         ->groupBy('panggilan')
    //                         ->get();
                            // dd($needs);

    return view('layout/kamerad/kamerad', ['totem' => $totem, 'kamerads' => $kamerads, 'widprodi' => $widprodi, 'widangkatan' => $widangkatan, 'widstatus' => $widstatus]);
  }

  public function alumni()
  {
    $totem = 'alumni';

    $kamerads = DB::table('tb_anggota')
                    ->join('prodi', 'tb_anggota.kode_prodi', '=', 'prodi.kode_prodi')
                    ->where('status', '2')
                    ->orderBy('angkatan', 'asc')
                    ->get();

    $widprodi = DB::select('select prodi, count(*) as jumlah from prodi, tb_anggota
                          where prodi.kode_prodi = tb_anggota.kode_prodi and status = :status
                          group by prodi	order by jumlah desc', ['status' => '2']);

    $widangkatan = DB::select('select angkatan, count(*) as jumlah from tb_anggota
                          where status = :status
                          group by angkatan	order by angkatan desc', ['status' => '2']);

    $widstatus = DB::select('select status, count(*) as jumlah from tb_anggota
                          group by status desc');

    // $needs = DB::table('tb_anggota')
    //                         ->join('tb_konten', 'tb_anggota.nim', '=', 'tb_konten.redaktur')
    //                         ->select(DB::raw('count(*) as jumlah, panggilan, image, nim'))
    //                         ->where('status', '0')
    //                         ->orderBy('jumlah', 'desc')
    //                         ->groupBy('panggilan')
    //                         ->get();
                            // dd($needs);

    return view('layout/kamerad/kamerad', ['totem' => $totem, 'kamerads' => $kamerads, 'widprodi' => $widprodi, 'widangkatan' => $widangkatan, 'widstatus' => $widstatus]);
  }

  public function create()
  {

    $prodis = DB::select('select * from prodi order by prodi asc');

    return view('layout/kamerad/tambah-kamerad', ['prodis' => $prodis]);

  }

  public function store(Request $request)
  {
    $nim = $request->nim;
    if ($request->image == '') {
      $kamerad = DB::table('tb_anggota')
                ->insert(['nim'           =>  $request->nim,
                          'nama'          =>  $request->nama,
                          'panggilan'     =>  $request->panggilan,
                          'tempat_lahir'  =>  $request->tempat_lahir,
                          'tgl_lahir'     =>  $request->tgl_lahir,
                          'kode_prodi'    =>  $request->kode_prodi,
                          'kelamin'       =>  $request->kelamin,
                          'agama'         =>  $request->agama,
                          'gol_darah'     =>  $request->gol_darah,
                          'alamat_asal'   =>  $request->alamat_asal,
                          'alamat_yogya'  =>  $request->alamat_yogya,
                          'email'         =>  $request->email,
                          'password'      =>  $request->password,
                          'hape'          =>  $request->hape,
                          'angkatan'      =>  $request->angkatan,
                          'status'        =>  $request->status,]);
    } else {
      $kamerad = DB::table('tb_anggota')
                ->insert(['nim'           =>  $request->nim,
                          'nama'          =>  $request->nama,
                          'panggilan'     =>  $request->panggilan,
                          'tempat_lahir'  =>  $request->tempat_lahir,
                          'tgl_lahir'     =>  $request->tgl_lahir,
                          'kode_prodi'    =>  $request->kode_prodi,
                          'kelamin'       =>  $request->kelamin,
                          'agama'         =>  $request->agama,
                          'gol_darah'     =>  $request->gol_darah,
                          'alamat_asal'   =>  $request->alamat_asal,
                          'alamat_yogya'  =>  $request->alamat_yogya,
                          'email'         =>  $request->email,
                          'password'      =>  $request->password,
                          'hape'          =>  $request->hape,
                          'image'         =>  $request->image,
                          'angkatan'      =>  $request->angkatan,
                          'status'        =>  $request->status,]);
    }

    return redirect()->action('KameradController@show', ['nim' => $nim]);

  }

  public function show($nim)
  {

    $kamerad = DB::table('tb_anggota')
                  ->join('prodi', 'tb_anggota.kode_prodi', '=', 'prodi.kode_prodi')
                  ->where('nim', $nim)
                  ->first();

    $rubriks = DB::select('select kode_rubrik, nama_rubrik from rubrik order by kode_rubrik asc');
    $isus = DB::select('select kode_isu, nama_isu from isu order by kode_isu asc');

    $statrubrik = DB::select('select kode_rubrik, count(*) as jumlah from tb_konten
    													   where redaktur = :nim
                                 group by kode_rubrik;', ['nim' => $nim]);
                                 // dd($statrubrik);

    $statisu = DB::select('select kode_isu, count(*) as jumlah from tb_konten
     													    where redaktur = :nim
                                  group by kode_isu;', ['nim' => $nim]);

    $aktivitas = DB::select('select *, datediff(curdate(), tanggal) as day from aktivitas
                                  where nim = :nim
                                  order by tanggal desc', ['nim' => $nim]);
                                  // dd($aktivitas);

    return view('layout/kamerad/detail-kamerad', ['kamerad' => $kamerad, 'rubriks' => $rubriks, 'isus' => $isus,
                                                  'statrubrik' => $statrubrik, 'statisu' => $statisu, 'aktivitas' => $aktivitas]);

  }

  public function edit($nim)
  {

    $kamerad = DB::table('tb_anggota')
                  ->where('nim', $nim)
                  ->first();

    $prodis = DB::select('select * from prodi order by prodi asc');

    return view('layout/kamerad/edit-kamerad', ['kamerad' => $kamerad, 'prodis' => $prodis]);

  }

  public function update(Request $request, $nim)
  {

    
    if ($request->image == '') {
      $kamerad = DB::table('tb_anggota')
                ->where('nim', $nim)
                ->update(['nama'          =>  $request->nama,
                          'panggilan'     =>  $request->panggilan,
                          'tempat_lahir'  =>  $request->tempat_lahir,
                          'tgl_lahir'     =>  $request->tgl_lahir,
                          'kode_prodi'    =>  $request->kode_prodi,
                          'kelamin'       =>  $request->kelamin,
                          'agama'         =>  $request->agama,
                          'gol_darah'     =>  $request->gol_darah,
                          'alamat_asal'   =>  $request->alamat_asal,
                          'alamat_yogya'  =>  $request->alamat_yogya,
                          'email'         =>  $request->email,
                          'password'      =>  $request->password,
                          'hape'          =>  $request->hape,
                          'angkatan'      =>  $request->angkatan,
                          'status'        =>  $request->status,]);
    } else {
      $kamerad = DB::table('tb_anggota')
                ->where('nim', $nim)
                ->update(['nama'          =>  $request->nama,
                          'panggilan'     =>  $request->panggilan,
                          'tempat_lahir'  =>  $request->tempat_lahir,
                          'tgl_lahir'     =>  $request->tgl_lahir,
                          'kode_prodi'    =>  $request->kode_prodi,
                          'kelamin'       =>  $request->kelamin,
                          'agama'         =>  $request->agama,
                          'gol_darah'     =>  $request->gol_darah,
                          'alamat_asal'   =>  $request->alamat_asal,
                          'alamat_yogya'  =>  $request->alamat_yogya,
                          'email'         =>  $request->email,
                          'password'      =>  $request->password,
                          'hape'          =>  $request->hape,
                          'image'         =>  $request->image,
                          'angkatan'      =>  $request->angkatan,
                          'status'        =>  $request->status,]);

    }

    return redirect()->action('KameradController@show', ['nim' => $nim]);

  }

  public function destroy($nim)
  {

    $konten = DB::table('tb_anggota')
              ->where('nim', '=', $nim)
              ->delete();

    return redirect('/kamerad');

  }
}
