<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TerbitanController extends Controller
{
  public function index()
  {

    $kontens = DB::select('select * from tb_konten, rubrik, isu, tb_anggota where
                            tb_konten.kode_rubrik = rubrik.kode_rubrik and
                            tb_konten.kode_isu = isu.kode_isu and
                            tb_konten.redaktur = tb_anggota.nim
                            order by tgl_konten desc limit 15');

                            //where perlu diganti tiap tahun
    $widgrafik = DB::table('tb_konten')
                            ->select(DB::raw('count(*) as jumlah, week(tgl_konten) as week'))
                            ->where('tgl_konten', '>', '2018-01-01')
                            ->orderBy('tgl_konten', 'asc')
                            ->groupBy('week')
                            ->get();
                            // dd($widgrafik);

    $n = 1;

    $widrubrik = DB::select('select nama_rubrik, count(*) as jumlah from rubrik, tb_konten
                            where rubrik.kode_rubrik = tb_konten.kode_rubrik
                            group by nama_rubrik	order by jumlah asc;');

    $widisu = DB::select('select nama_isu, count(*) as jumlah from isu, tb_konten
                            where isu.kode_isu = tb_konten.kode_isu
                            group by nama_isu	order by jumlah desc;');

    $widkamerad = DB::select('select count(*) as jumlah, panggilan, image, nim from tb_anggota, tb_konten
                          where tb_anggota.nim = tb_konten.redaktur and status = :status and tb_anggota.nim != :nim
                          group by panggilan order by jumlah desc limit 5', ['status' => '0', 'nim' => '11']);

    return view('layout/terbitan/terbitan', ['kontens' => $kontens, 'widgrafik' => $widgrafik, 'widrubrik' => $widrubrik, 'widisu' => $widisu, 'widkamerad' => $widkamerad, 'n' => $n]);

  }

  public function full()
  {

    $kontens = DB::select('select * from tb_konten, rubrik, isu, tb_anggota where
                            tb_konten.kode_rubrik = rubrik.kode_rubrik and
                            tb_konten.kode_isu = isu.kode_isu and
                            tb_konten.redaktur = tb_anggota.nim
                            order by tgl_konten desc');

                            //where perlu diganti tiap tahun
    $widgrafik = DB::table('tb_konten')
                            ->select(DB::raw('count(*) as jumlah, week(tgl_konten) as week'))
                            ->where('tgl_konten', '>', '2018-01-01')
                            ->orderBy('tgl_konten', 'asc')
                            ->groupBy('week')
                            ->get();
                            // dd($widgrafik);

    $n = 1;

    $widrubrik = DB::select('select nama_rubrik, count(*) as jumlah from rubrik, tb_konten
                            where rubrik.kode_rubrik = tb_konten.kode_rubrik
                            group by nama_rubrik	order by jumlah asc;');

    $widisu = DB::select('select nama_isu, count(*) as jumlah from isu, tb_konten
                            where isu.kode_isu = tb_konten.kode_isu
                            group by nama_isu	order by jumlah desc;');

    $widkamerad = DB::table('tb_anggota')
                            ->join('tb_konten', 'tb_anggota.nim', '=', 'tb_konten.redaktur')
                            ->select(DB::raw('count(*) as jumlah, panggilan, image, nim'))
                            ->orderBy('jumlah', 'desc')
                            ->groupBy('panggilan')
                            ->take(5)
                            ->get();

    return view('layout/terbitan/terbitan', ['kontens' => $kontens, 'widgrafik' => $widgrafik, 'widrubrik' => $widrubrik, 'widisu' => $widisu, 'widkamerad' => $widkamerad, 'n' => $n]);
  }

    public function create()
    {

      $redakturs = DB::select('select nim, panggilan from tb_anggota order by panggilan asc');
      $rubriks = DB::select('select kode_rubrik, nama_rubrik from rubrik order by kode_rubrik asc');
      $isus = DB::select('select kode_isu, nama_isu from isu order by kode_isu asc');

      return view('layout/terbitan/create-terbitan', ['redakturs' => $redakturs, 'rubriks' => $rubriks, 'isus' => $isus]);

    }

    public function store(Request $request)
    {

      $konten = DB::table('tb_konten')
                ->insert(['judul_konten'  =>  $request->judul_konten,
                          'link'          =>  $request->link,
                          'tgl_konten'    =>  $request->tgl_konten,
                          'redaktur'      =>  $request->redaktur,
                          'kode_rubrik'   =>  $request->kode_rubrik,
                          'kode_isu'      =>  $request->kode_isu]);

      return redirect('/terbitan');

    }

    public function edit($idTerbitan)
    {

      $konten = DB::table('tb_konten')->where('id_konten', $idTerbitan)->first();

      $redakturs = DB::select('select nim, panggilan from tb_anggota order by panggilan asc');
      $rubriks = DB::select('select kode_rubrik, nama_rubrik from rubrik order by kode_rubrik asc');
      $isus = DB::select('select kode_isu, nama_isu from isu order by kode_isu asc');

      return view('layout/terbitan/edit-terbitan', ['konten' => $konten, 'redakturs' => $redakturs, 'rubriks' => $rubriks, 'isus' => $isus]);

    }

    public function update(Request $request, $idTerbitan)
    {

      $konten = DB::table('tb_konten')
                ->where('id_konten', $idTerbitan)
                ->update(['judul_konten'  =>  $request->judul_konten,
                          'link'          =>  $request->link,
                          'tgl_konten'    =>  $request->tgl_konten,
                          'redaktur'      =>  $request->redaktur,
                          'kode_rubrik'   =>  $request->kode_rubrik,
                          'kode_isu'      =>  $request->kode_isu]);

      return redirect('/terbitan');

    }

    public function destroy($idTerbitan)
    {

      $konten = DB::table('tb_konten')
                ->where('id_konten', '=', $idTerbitan)
                ->delete();

      return redirect('/terbitan');

    }
}
