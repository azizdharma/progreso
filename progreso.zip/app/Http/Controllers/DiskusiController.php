<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DiskusiController extends Controller
{
  public function index()
  {
    $diskusis = DB::table('tb_diskusi')
                    ->join('tb_anggota', 'tb_diskusi.pemantik', '=', 'tb_anggota.nim')
                    ->orderBy('tgl_diskusi', 'desc')
                    ->limit(15)
                    ->get();

    $widgrafik = DB::table('tb_diskusi')
                            ->select(DB::raw('count(*) as jumlah, month(tgl_diskusi) as month'))
                            ->where('tgl_diskusi', '>', '2018-01-01')
                            ->orderBy('tgl_diskusi', 'asc')
                            ->groupBy('month')
                            ->get();
                            // dd($widgrafik);

    $widdiskusi = DB::select('select jenis_diskusi, count(*) as jumlah from tb_diskusi
                            group by jenis_diskusi	order by jumlah asc;');

    $widpemantik = DB::table('tb_anggota')
                            ->join('tb_diskusi', 'tb_anggota.nim', '=', 'tb_diskusi.pemantik')
                            ->select(DB::raw('count(*) as jumlah, panggilan, image, nim'))
                            ->orderBy('jumlah', 'desc')
                            ->groupBy('panggilan')
                            ->take(5)
                            ->get();

    return view('layout/diskusi/diskusi', ['diskusis' => $diskusis, 'widgrafik' => $widgrafik, 'widdiskusi' => $widdiskusi, 'widpemantik' => $widpemantik]);
  }

  public function full()
  {
    $diskusis = DB::table('tb_diskusi')
                    ->join('tb_anggota', 'tb_diskusi.pemantik', '=', 'tb_anggota.nim')
                    ->orderBy('tgl_diskusi', 'desc')
                    ->get();

    $widgrafik = DB::table('tb_diskusi')
                            ->select(DB::raw('count(*) as jumlah, month(tgl_diskusi) as month'))
                            ->orderBy('tgl_diskusi', 'asc')
                            ->groupBy('month')
                            ->get();

    $widdiskusi = DB::select('select jenis_diskusi, count(*) as jumlah from tb_diskusi
                            group by jenis_diskusi	order by jumlah asc;');

    $widpemantik = DB::table('tb_anggota')
                            ->join('tb_diskusi', 'tb_anggota.nim', '=', 'tb_diskusi.pemantik')
                            ->select(DB::raw('count(*) as jumlah, panggilan, image, nim'))
                            ->orderBy('jumlah', 'desc')
                            ->groupBy('panggilan')
                            ->take(5)
                            ->get();

    return view('layout/diskusi/diskusi', ['diskusis' => $diskusis, 'widgrafik' => $widgrafik, 'widdiskusi' => $widdiskusi, 'widpemantik' => $widpemantik]);
  }

    public function create()
    {

      $pemantiks = DB::select('select nim, panggilan from tb_anggota order by panggilan asc');

      return view('layout/diskusi/tambah-diskusi', ['pemantiks' => $pemantiks]);

    }

    public function store(Request $request)
    {

      $konten = DB::table('tb_diskusi')
                ->insert(['judul_diskusi'  =>  $request->judul_diskusi,
                          'tgl_diskusi'    =>  $request->tgl_diskusi,
                          'pemantik'      =>  $request->pemantik,
                          'jenis_diskusi'   =>  $request->jenis_diskusi]);

      return redirect('/diskusi');

    }

    public function edit($idDiskusi)
    {

      $diskusi = DB::table('tb_diskusi')->where('kode_diskusi', $idDiskusi)->first();

      $pemantiks = DB::select('select nim, panggilan from tb_anggota order by panggilan asc');

      return view('layout/diskusi/edit-diskusi', ['diskusi' => $diskusi, 'pemantiks' => $pemantiks]);

    }

    public function update(Request $request, $idDiskusi)
    {

      $konten = DB::table('tb_diskusi')
                ->where('kode_diskusi', $idDiskusi)
                ->update(['judul_diskusi'  =>  $request->judul_diskusi,
                          'tgl_diskusi'    =>  $request->tgl_diskusi,
                          'pemantik'      =>  $request->pemantik,
                          'jenis_diskusi'   =>  $request->jenis_diskusi]);

      return redirect('/diskusi');

    }

    public function destroy($idDiskusi)
    {

      $konten = DB::table('tb_diskusi')
                ->where('kode_diskusi', '=', $idDiskusi)
                ->delete();

      return redirect('/diskusi');

    }
}
