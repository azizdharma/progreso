<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    @include('layout.parts.head')
  </head>
  <body>
    @include('layout.parts.navlogin')
    <main role="main" class="container">
      <div class="col-md-8 bg-pink">
      tes
      </div>
      <div class="row">
        <div class="col-md-12">
          <br><br><br>
        </div>
      </div>
    </main>
    @include('layout.parts.footer')
  </body>
</html>
