<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="{{ url('css/bootstrap.css') }}">
<link rel="icon" href="{{ url('img/fav-progreso.png') }}">
<!-- Custom styles for this template -->
<link rel="stylesheet" href="{{ url('css/progres-template.css') }}">
<link rel="stylesheet" href="{{ url('css/print.min.css') }}">
<link href="https://fonts.googleapis.com/css?family=PT+Sans" rel="stylesheet"> 
<title>Progreso | Banyak orang hanya menyambung hidup, kita harus juga mengisinya</title>
