<nav class="navbar navbar-expand-md navbar-dark bg-progreso fixed-top">
  <div class="container">
    <a class="navbar-brand" href="/">
      <img src="{{ url('img/logo-progreso.png') }}" alt="">
    </a>
    <div class="collapse navbar-collapse" id="navbarsKiri">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="/">Capaian Belajarku</a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="/aktivitas">Aktivitas</a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="/terbitan">Terbitan</a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="/diskusi">Diskusi</a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="/kamerad">Kamerad</a>
        </li>
      </ul>
    </div>
    <form class="form-inline my-2 my-lg-0">
      <div class="collapse navbar-collapse" id="navbarsKanan">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item dropdown active">
            <a class="nav-link dropdown-toggle" href="https://example.com" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">Aziz</a>
            <div class="dropdown-menu" aria-labelledby="dropdown01">
              <a class="dropdown-item" href="#">Profil</a>
              <a class="dropdown-item" href="#">Pengaturan</a>
              <a class="dropdown-item" href="/manifesto">Manifesto</a>
              <a class="dropdown-item" href="#">Keluar</a>
            </div>
          </li>
        </ul>
      </div>
      {{-- <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="#"><img src="{{ url('img/heat.png') }}" alt="runtutan"> 0</a>
        </li>
      </ul>
      <button class="btn btn-info my-2 my-sm-0 rounded-circle" type="submit">
        <img src="{{ url('img/notif.png') }}" alt="">
      </button> --}}
    </form>
  </div>
</nav>
