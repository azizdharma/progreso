<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    @include('layout.parts.head')
  </head>
  <body>
    @include('layout.parts.nav')
    <main role="main" class="container">
      @yield('content')
    </main>
    @include('layout.parts.footer')
  </body>
</html>
