@extends('layout.main')

@section('content')
<div class="row">
  <!-- start of mainbar -->
  <div class="col-md-8" id="mainBar">
    <div class="card">
      <div class="card-body">
        <div class="container">
          <br>
          <h3>Aktivitas</h3>
          <br> <br>
          <ul class="list-unstyled activity-timeline">
            @foreach ($aktivitas as $akt)
              @if ($akt->meta != '' )
                <li>
                  <div class="row">
                    <div class="col-md-1">
                      <a href="kamerad/{{ $akt->nim }}">
                        <img src="img/{{ $akt->image }}" alt="Avatar" class="rounded-2 pull-left avatar" width="50px" height="50px">
                      </a>
                    </div>
                    <div class="col-md-10 pas">
                      <span class="">
                        {{ $akt->panggilan }} menulis <code class="biru">{{ $akt->jenis }}</code> berjudul
                        <a class="alert-link" target="_blank" href="{{ $akt->meta }}"> {{ $akt->judul }}</a>.
                      </span>
                      <span class="timestamp ">
                        <i class="activity-icon"></i>
                        @if ($akt->day >= 1)
                          {{ $akt->day }} hari yang lalu.
                        @elseif ($akt->day <= 0)
                          {{ $akt->day }} hari lagi.
                          @else
                            Hari ini.
                        @endif
                      </span>
                    </div>
                  </div>
                </li>
                <hr>
                @else
                  <li>
                    <div class="row">
                      <div class="col-md-1">
                        <a href="kamerad/{{ $akt->nim }}">
                          <img src="img/{{ $akt->image }}" alt="Avatar" class="rounded-2 pull-left avatar" width="50px" height="50px">
                        </a>
                      </div>
                      <div class="col-md-10 pas">
                        <span class="">
                          {{ $akt->panggilan }} menjadi pemantik <code class="hijau">{{ $akt->jenis }}</code> bertema
                          <a class="alert-link">{{ $akt->judul }}</a>.
                        </span>
                        <span class="timestamp">
                          <i class="activity-icona"></i>
                          @if ($akt->day >= 1)
                            {{ $akt->day }} hari yang lalu.
                          @elseif ($akt->day <= 0)
                            {{ $akt->day }} hari lagi.
                            @else
                              Hari ini.
                          @endif
                        </span>
                      </div>
                  </div>
                </li>
                <hr>
              @endif
            @endforeach
            @if (count($aktivitas) < 11)
              <li>
                <div class="row">
                  <div class="col-md-12">
                    <center><a href="/aktivitas-full" role="button" class="btn btn-success rounded col-md-3 tt"> <b class="putih"> SELENGKAPNYA </b></a></center>
                  </div>
                </div>
              </li>
            @endif
          </ul>
        </div>
      </div>
    </div>
    <br>
  </div>
  <!-- end of mainbar -->
  <!--start of sidebar -->

  <!-- end of sidebar -->
</div>


@endsection
