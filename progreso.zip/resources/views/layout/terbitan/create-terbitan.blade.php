@extends('layout.main')

@section('content')
<div class="row">
  <!-- start of mainbar -->
  <div class="col-8" id="mainBar">
    <div class="card">
      <div class="card-body">
        <div class="container">
          <form action="/terbitan" method="post">
          <input type="hidden" name="_method" value="POST">
          {{ csrf_field() }}
          <br>
          <div class="row">
            <div class="col-7">
              <h3>Tambah Terbitan</h3>
            </div>
            <div class="col-5">

            </div>
          </div>
          <br>
          <br>
          <br>
            <div class="form-group row">
              <label for="inputJudul" class="col-sm-3 col-form-label kanan">Judul</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="judul_konten" placeholder="Judul">
              </div>
            </div>
            <div class="form-group row">
              <label for="inputTautan" class="col-sm-3 col-form-label kanan">Tautan</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="link" placeholder="Tautan">
              </div>
            </div>
            <div class="form-group row">
              <label for="inputTanggal" class="col-sm-3 col-form-label kanan">Tanggal</label>
              <div class="col-sm-8">
                <input type="date" class="form-control custom-select col-sm-6" name="tgl_konten" placeholder="Tanggal">
              </div>
            </div>
            <div class="form-group row">
              <label for="inputRedaktur" class="col-sm-3 col-form-label kanan">Redaktur</label>
              <div class="col-sm-8">
                <select name="redaktur" class="form-control custom-select mr-sm-2 col-sm-6">
                  @foreach ($redakturs as $redaktur)

                    @if ($redaktur->nim == 11)
                      <option selected value="{{ $redaktur->nim }}">{{ $redaktur->panggilan }}</option>
                    @else
                      <option value="{{ $redaktur->nim }}">{{ $redaktur->panggilan }}</option>
                    @endif

                  @endforeach
                </select>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputRubrik" class="col-sm-3 col-form-label kanan">Rubrik</label>
              <div class="col-sm-8">
                <select name="kode_rubrik" class="form-control custom-select mr-sm-2 col-sm-6">
                  @foreach ($rubriks as $rubrik)

                      <option value="{{ $rubrik->kode_rubrik }}">{{ $rubrik->nama_rubrik }}</option>

                  @endforeach
                </select>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputIsu" class="col-sm-3 col-form-label kanan">Isu</label>
              <div class="col-sm-8">
                <select name="kode_isu" class="form-control custom-select mr-sm-2 col-sm-6">
                  @foreach ($isus as $isu)

                      <option value="{{ $isu->kode_isu }}">{{ $isu->nama_isu }}</option>

                  @endforeach
                </select>
              </div>
            </div>
            <br>
            <div class="form-group row">
              <label for="inputIsu" class="col-sm-3 col-form-label kanan"></label>
              <div class="col-sm-8">
                <button type="submit" name="submit" value="create" class="btn btn-success rounded "><b>&nbsp;SIMPAN&nbsp;</b></button>
              </div>
            </div>
          </form>
          <br>
        </div>
      </div>
    </div>
    <br>
  </div>
  <!-- end of mainbar -->
</div>
@endsection
