@extends('layout.main')

@section('content')
<div class="row">
  <!-- start of mainbar -->
  <div class="col-8" id="mainBar">
    <div class="card">
      <div class="card-body">
        <div class="container">

          <br>
          <div class="row">
            <div class="col-7">
              <h3>Edit Terbitan</h3>
            </div>
            <div class="col-5">

            </div>
          </div>
          <br>
          <br>
          <br>
          <form action="/terbitan/{{ $konten->id_konten }}" method="post">
          <input type="hidden" name="_method" value="PUT">
          {{ csrf_field() }}
            <div class="form-group row">
              <label for="inputJudul" class="col-sm-3 col-form-label kanan">Judul</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="judul_konten" placeholder="Judul" value="{{ $konten->judul_konten }}">
              </div>
            </div>
            <div class="form-group row">
              <label for="inputTautan" class="col-sm-3 col-form-label kanan">Tautan</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="link" placeholder="Tautan" value="{{ $konten->link }}">
              </div>
            </div>
            <div class="form-group row">
              <label for="inputTanggal" class="col-sm-3 col-form-label kanan">Tanggal</label>
              <div class="col-sm-8">
                <input type="date" class="form-control custom-select col-sm-6" name="tgl_konten" placeholder="Tautan" value="{{ $konten->tgl_konten }}">
              </div>
            </div>
            <div class="form-group row">
              <label for="inputRedaktur" class="col-sm-3 col-form-label kanan">Redaktur</label>
              <div class="col-sm-8">
                <select name="redaktur" class="form-control custom-select mr-sm-2 col-sm-6">
                  @foreach ($redakturs as $redaktur)

                    @if ($redaktur->nim == $konten->redaktur)
                      <option selected value="{{ $redaktur->nim }}">{{ $redaktur->panggilan }}</option>
                    @else
                      <option value="{{ $redaktur->nim }}">{{ $redaktur->panggilan }}</option>
                    @endif

                  @endforeach
                </select>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputRubrik" class="col-sm-3 col-form-label kanan">Rubrik</label>
              <div class="col-sm-8">
                <select name="kode_rubrik" class="form-control custom-select mr-sm-2 col-sm-6">
                  @foreach ($rubriks as $rubrik)

                    @if ($rubrik->kode_rubrik == $konten->kode_rubrik)
                      <option selected value="{{ $rubrik->kode_rubrik }}">{{ $rubrik->nama_rubrik }}</option>
                    @else
                      <option value="{{ $rubrik->kode_rubrik }}">{{ $rubrik->nama_rubrik }}</option>
                    @endif

                  @endforeach
                </select>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputIsu" class="col-sm-3 col-form-label kanan">Isu</label>
              <div class="col-sm-8">
                <select name="kode_isu" class="form-control custom-select mr-sm-2 col-sm-6">
                  @foreach ($isus as $isu)

                    @if ($isu->kode_isu == $konten->kode_isu)
                      <option selected value="{{ $isu->kode_isu }}">{{ $isu->nama_isu }}</option>
                    @else
                      <option value="{{ $isu->kode_isu }}">{{ $isu->nama_isu }}</option>
                    @endif

                  @endforeach
                </select>
              </div>
            </div>
            <br>
            <div class="form-group row">
              <label for="inputIsu" class="col-sm-3 col-form-label kanan"></label>
              <div class="col-sm-8">
                <button type="submit" name="submit" value="edit" class="btn btn-success rounded "><b>&nbsp;SIMPAN&nbsp;</b></button>
              </div>
            </div>
          </form>
          <div class="form-group row">
            <label for="inputIsu" class="col-sm-3 col-form-label kanan"></label>
            <div class="col-sm-8">
              <button type="submit" name="submit" class="btn btn-danger" data-toggle="modal" data-target="#HapusTerbitan">
                <b>&nbsp;HAPUS&nbsp;</b>
              </button>
            </div>
          </div>

          <br>
        </div>
      </div>
    </div>
    <br>
  </div>
  <!-- end of mainbar -->
</div>

<!-- Modal Hapus Terbitan-->
<div class="modal fade" id="HapusTerbitan" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <br>
        <h6>
          Apakah Anda yakin ingin menghapus terbitan ini?
        </h6>
        <br>
        <button type="button" class="btn btn-secondary marg float-right" data-dismiss="modal">Batal</button>

        <form action="/terbitan/{{ $konten->id_konten }}" method="post">
          <input type="hidden" name="_method" value="delete">
          {{ csrf_field() }}
        <button type="submit" class="btn btn-danger rounded float-right" value="delete"><b>&nbsp;&nbsp;HAPUS&nbsp;&nbsp;</b></button>
        </form>

      </div>
    </div>
  </div>
</div>

@endsection
