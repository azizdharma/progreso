@extends('layout.main')

@section('content')
<div class="row">
  <!-- start of mainbar -->
  <div class="col-8" id="mainBar">
    <div class="card">
      <div class="card-body">
        <div class="container">
          <form action="/diskusi" method="post">
          <input type="hidden" name="_method" value="POST">
          {{ csrf_field() }}
          <br>
          <div class="row">
            <div class="col-7">
              <h3>Tambah Diskusi</h3>
            </div>
            <div class="col-5">

            </div>
          </div>
          <br>
          <br>
          <br>
            <div class="form-group row">
              <label for="inputJudul" class="col-sm-3 col-form-label kanan">Judul Diskusi</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="judul_diskusi" placeholder="Judul">
              </div>
            </div>
            <div class="form-group row">
              <label for="inputTanggal" class="col-sm-3 col-form-label kanan">Tanggal</label>
              <div class="col-sm-8">
                <input type="date" class="form-control custom-select col-sm-6" name="tgl_diskusi" placeholder="Tanggal">
              </div>
            </div>
            <div class="form-group row">
              <label for="inputpemantik" class="col-sm-3 col-form-label kanan">Pemantik</label>
              <div class="col-sm-8">
                <select name="pemantik" class="form-control custom-select mr-sm-2 col-sm-6">
                  @foreach ($pemantiks as $pemantik)

                    @if ($pemantik->nim == 11)
                      <option selected value="{{ $pemantik->nim }}">{{ $pemantik->panggilan }}</option>
                    @else
                      <option value="{{ $pemantik->nim }}">{{ $pemantik->panggilan }}</option>
                    @endif

                  @endforeach
                </select>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputRubrik" class="col-sm-3 col-form-label kanan">Jenis Diskusi</label>
              <div class="col-sm-8">
                <select name="jenis_diskusi" class="form-control custom-select mr-sm-2 col-sm-6">
                  <option value="KCM">Kajian Cinta Menulis</option>
                  <option value="KCB">Kajian Cinta Baca</option>
                  <option value="KSF">Kesengsem Foto</option>
                  <option value="KJM">Kajian Jumat Malam</option>
                  <option value="ART">Diskusi Artistik</option>
                  <option value="MJL">Presentasi Tema Majalah</option>
                  <option value="BKU">Presentasi Tema Buku</option>
                  <option value="JKS">JK Share</option>
                  <option value="DLL">Lainnya</option>
                </select>
              </div>
            </div>
            <br>
            <div class="form-group row">
              <label for="inputIsu" class="col-sm-3 col-form-label kanan"></label>
              <div class="col-sm-8">
                <button type="submit" name="submit" value="create" class="btn btn-success rounded"><b>&nbsp;SIMPAN&nbsp;</b></button>
              </div>
            </div>
          </form>
          <br>
        </div>
      </div>
    </div>
    <br>
  </div>
  <!-- end of mainbar -->
</div>
@endsection
