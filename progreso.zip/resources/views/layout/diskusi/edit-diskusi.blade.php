@extends('layout.main')

@section('content')
<div class="row">
  <!-- start of mainbar -->
  <div class="col-8" id="mainBar">
    <div class="card">
      <div class="card-body">
        <div class="container">
          <form action="/diskusi/{{ $diskusi->kode_diskusi }}" method="post">
          <input type="hidden" name="_method" value="PUT">
          {{ csrf_field() }}
          <br>
          <div class="row">
            <div class="col-7">
              <h3>Edit Diskusi</h3>
            </div>
            <div class="col-5">

            </div>
          </div>
          <br>
          <br>
          <br>
            <div class="form-group row">
              <label for="inputJudul" class="col-sm-3 col-form-label kanan">Judul Diskusi</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="judul_diskusi" placeholder="Judul" value="{{ $diskusi->judul_diskusi }}">
              </div>
            </div>
            <div class="form-group row">
              <label for="inputTanggal" class="col-sm-3 col-form-label kanan">Tanggal</label>
              <div class="col-sm-8">
                <input type="date" class="form-control custom-select col-sm-6" name="tgl_diskusi" placeholder="Tanggal" value="{{ $diskusi->tgl_diskusi }}">
              </div>
            </div>
            <div class="form-group row">
              <label for="inputpemantik" class="col-sm-3 col-form-label kanan">Pemantik</label>
              <div class="col-sm-8">
                <select name="pemantik" class="form-control custom-select mr-sm-2 col-sm-6">
                  @foreach ($pemantiks as $pemantik)

                    @if ($pemantik->nim == $diskusi->pemantik)
                      <option selected value="{{ $pemantik->nim }}">{{ $pemantik->panggilan }}</option>
                    @else
                      <option value="{{ $pemantik->nim }}">{{ $pemantik->panggilan }}</option>
                    @endif

                  @endforeach
                </select>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputRubrik" class="col-sm-3 col-form-label kanan">Jenis Diskusi</label>
              <div class="col-sm-8">
                <select name="jenis_diskusi" class="form-control custom-select mr-sm-2 col-sm-6">
                  @if ($diskusi->jenis_diskusi == 'KCM')
                    <option selected value="KCM">Kajian Cinta Menulis</option>
                    <option value="KCB">Kajian Cinta Baca</option>
                    <option value="KSF">Kesengsem Foto</option>
                    <option value="KJM">Kajian Jumat Malam</option>
                    <option value="ART">Diskusi Artistik</option>
                    <option value="MJL">Presentasi Tema Majalah</option>
                    <option value="BKU">Presentasi Tema Buku</option>
                    <option value="JKS">JK Share</option>
                    <option value="DLL">Lainnya</option>
                  @elseif ($diskusi->jenis_diskusi == 'KCB')
                    <option value="KCM">Kajian Cinta Menulis</option>
                    <option selected value="KCB">Kajian Cinta Baca</option>
                    <option value="KSF">Kesengsem Foto</option>
                    <option value="KJM">Kajian Jumat Malam</option>
                    <option value="ART">Diskusi Artistik</option>
                    <option value="MJL">Presentasi Tema Majalah</option>
                    <option value="BKU">Presentasi Tema Buku</option>
                    <option value="JKS">JK Share</option>
                    <option value="DLL">Lainnya</option>
                  @elseif ($diskusi->jenis_diskusi == 'KSF')
                    <option value="KCM">Kajian Cinta Menulis</option>
                    <option value="KCB">Kajian Cinta Baca</option>
                    <option selected value="KSF">Kesengsem Foto</option>
                    <option value="KJM">Kajian Jumat Malam</option>
                    <option value="ART">Diskusi Artistik</option>
                    <option value="MJL">Presentasi Tema Majalah</option>
                    <option value="BKU">Presentasi Tema Buku</option>
                    <option value="JKS">JK Share</option>
                    <option value="DLL">Lainnya</option>
                  @elseif ($diskusi->jenis_diskusi == 'KJM')
                    <option value="KCM">Kajian Cinta Menulis</option>
                    <option value="KCB">Kajian Cinta Baca</option>
                    <option value="KSF">Kesengsem Foto</option>
                    <option selected value="KJM">Kajian Jumat Malam</option>
                    <option value="ART">Diskusi Artistik</option>
                    <option value="MJL">Presentasi Tema Majalah</option>
                    <option value="BKU">Presentasi Tema Buku</option>
                    <option value="JKS">JK Share</option>
                    <option value="DLL">Lainnya</option>
                  @elseif ($diskusi->jenis_diskusi == 'ART')
                    <option value="KCM">Kajian Cinta Menulis</option>
                    <option value="KCB">Kajian Cinta Baca</option>
                    <option value="KSF">Kesengsem Foto</option>
                    <option value="KJM">Kajian Jumat Malam</option>
                    <option selected value="ART">Diskusi Artistik</option>
                    <option value="MJL">Presentasi Tema Majalah</option>
                    <option value="BKU">Presentasi Tema Buku</option>
                    <option value="JKS">JK Share</option>
                    <option value="DLL">Lainnya</option>
                  @elseif ($diskusi->jenis_diskusi == 'MJL')
                    <option value="KCM">Kajian Cinta Menulis</option>
                    <option value="KCB">Kajian Cinta Baca</option>
                    <option value="KSF">Kesengsem Foto</option>
                    <option value="KJM">Kajian Jumat Malam</option>
                    <option value="ART">Diskusi Artistik</option>
                    <option selected value="MJL">Presentasi Tema Majalah</option>
                    <option value="BKU">Presentasi Tema Buku</option>
                    <option value="JKS">JK Share</option>
                    <option value="DLL">Lainnya</option>
                  @elseif ($diskusi->jenis_diskusi == 'BKU')
                    <option value="KCM">Kajian Cinta Menulis</option>
                    <option value="KCB">Kajian Cinta Baca</option>
                    <option value="KSF">Kesengsem Foto</option>
                    <option value="KJM">Kajian Jumat Malam</option>
                    <option value="ART">Diskusi Artistik</option>
                    <option value="MJL">Presentasi Tema Majalah</option>
                    <option selected value="BKU">Presentasi Tema Buku</option>
                    <option value="JKS">JK Share</option>
                    <option value="DLL">Lainnya</option>
                  @elseif ($diskusi->jenis_diskusi == 'JKS')
                    <option value="KCM">Kajian Cinta Menulis</option>
                    <option value="KCB">Kajian Cinta Baca</option>
                    <option value="KSF">Kesengsem Foto</option>
                    <option value="KJM">Kajian Jumat Malam</option>
                    <option value="ART">Diskusi Artistik</option>
                    <option value="MJL">Presentasi Tema Majalah</option>
                    <option value="BKU">Presentasi Tema Buku</option>
                    <option selected value="JKS">JK Share</option>
                    <option value="DLL">Lainnya</option>
                  @elseif ($diskusi->jenis_diskusi == 'DLL')
                    <option value="KCM">Kajian Cinta Menulis</option>
                    <option value="KCB">Kajian Cinta Baca</option>
                    <option value="KSF">Kesengsem Foto</option>
                    <option value="KJM">Kajian Jumat Malam</option>
                    <option value="ART">Diskusi Artistik</option>
                    <option value="MJL">Presentasi Tema Majalah</option>
                    <option value="BKU">Presentasi Tema Buku</option>
                    <option value="JKS">JK Share</option>
                    <option selected value="DLL">Lainnya</option>
                  @endif
                </select>
              </div>
            </div>
            <br>
            <div class="form-group row">
              <label for="inputIsu" class="col-sm-3 col-form-label kanan"></label>
              <div class="col-sm-8">
                <button type="submit" name="submit" value="edit" class="btn btn-success rounded "><b>&nbsp;SIMPAN&nbsp;</b></button>
              </div>
            </div>
          </form>
          <div class="form-group row">
            <label for="inputIsu" class="col-sm-3 col-form-label kanan"></label>
            <div class="col-sm-8">
              <button type="submit" name="submit" class="btn btn-danger" data-toggle="modal" data-target="#Hapusdiskusi">
                <b>&nbsp;HAPUS&nbsp;</b>
              </button>
            </div>
          </div>
          </form>
          <br>
        </div>
      </div>
    </div>
    <br>
  </div>
  <!-- end of mainbar -->
</div>
<!-- Modal Hapus Diskusi-->
<div class="modal fade" id="Hapusdiskusi" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <br>
        <h6>
          Apakah Anda yakin ingin menghapus diskusi ini?
        </h6>
        <br>
        <button type="button" class="btn btn-secondary marg float-right" data-dismiss="modal">Batal</button>

        <form action="/diskusi/{{ $diskusi->kode_diskusi }}" method="post">
          <input type="hidden" name="_method" value="delete">
          {{ csrf_field() }}
        <button type="submit" class="btn btn-danger rounded float-right" value="delete"><b>&nbsp;&nbsp;HAPUS&nbsp;&nbsp;</b></button>
        </form>

      </div>
    </div>
  </div>
</div>
@endsection
