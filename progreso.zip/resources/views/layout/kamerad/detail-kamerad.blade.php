@extends('layout.main')

@section('content')
<div class="row">
  <!-- start of mainbar -->
  <div class="col-md-8" id="mainBar">
    <div class="card">
      <div class="card-body">
        <div class="container">
          <br>
          <div class="row">
            <div class="col-md-4 kiriq">
              <center>
              <div class="card" style="width: 100%;">
                <div class="card-header header-asoy bg-white rounded-top">
                  <br>
                </div>
                <div class="card-body">
                  <div class="ProfileCard-avatarLink">
                    <img src="../img/{{ $kamerad->image }}" class="float-left img-circle" width="100px" height="100px" alt="AVA">
                  </div>
                  <h6 class="card-title"><b>{{ $kamerad->nama }}</b></h6>
                  <span class="timestamp nim">{{ $kamerad->nim }}</span>
                  <span class="timestamp ">{{ $kamerad->prodi }}</span>
                  <div class="ProfileCardStats nim">
                    <ul type="none" class="ProfileCardStats-statList Arrange Arrange--bottom Arrange--equal">
                      <li class="stats">
                        <center>
                          <span class="ket-counter">Konten</span>
                          <span class="counter">
                            @php
                              $x = 0;
                            @endphp
                            @foreach ($statrubrik as $stat)
                              @php
                                $x = $x + $stat->jumlah;
                              @endphp
                            @endforeach
                            @php
                              echo $x;
                            @endphp
                          </span>
                        </center>
                      </li>
                      <li class="stats">
                        <center>
                          <span class="ket-counter">Diskusi</span>
                          <span class="counter">
                            @php
                              $z = count($aktivitas);
                              $y = $z - $x;
                              echo $y;
                            @endphp
                          </span>
                          </center>
                      </li>
                    </ul>
                  </div>
                </div>
                <hr>
              </div>

              <br>
              <a role="button" href="{{ $kamerad->nim }}/edit" class="btn btn-warning rounded col-md-9 col-sm-12">
                <b class="putih">SUNTING BIO</b>
              </a>
              <br> <br>
              <a role="button" href="#" class="btn btn-success rounded col-bg-3 col-md-9 col-sm-12" onclick="printJS('mainBar', 'html')">
                <b class="putih">CETAK PDF</b>
              </a>
              <br> <br>
              <button type="submit" class="btn btn-danger rounded col-md-9 col-sm-12" value="delete" data-toggle="modal" data-target="#HapusAkun">
                <b>HAPUS</b>
              </button>


              <br><br>

              </center>
            </div>
            <div class="col-md-8 kananq">
              <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item">
                  <a class="nav-link active judul" id="aktivitas-tab" data-toggle="tab" href="#aktivitas" role="tab" aria-controls="aktivitas" aria-selected="false">Aktivitas</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link judul" id="rubrik-tab" data-toggle="tab" href="#rubrik" role="tab" aria-controls="rubrik" aria-selected="true">Rubrik</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link judul" id="isu-tab" data-toggle="tab" href="#isu" role="tab" aria-controls="isu" aria-selected="false">Isu</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link judul" id="bio-tab" data-toggle="tab" href="#bio" role="tab" aria-controls="bio" aria-selected="false">Tentang</a>
                </li>
              </ul>
              <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade" id="bio" role="tabpanel" aria-labelledby="bio-tab">
                  <br>
                  <table class="table">
                    <tr>
                      <td class="no-border"><span class="float-right">Panggilan</span></td>
                      <td class="no-border"><span class="">{{ $kamerad->panggilan }}</span></td>
                    </tr>
                    <tr>
                      <td class=""><span class="float-right">Alamat</span></td>
                      <td class=""><span class="">{{ $kamerad->alamat_asal }}</span></td>
                    </tr>
                    <tr>
                      <td><span class="float-right"></span></td>
                      <td><span class="">{{ $kamerad->alamat_yogya }}</span></td>
                    </tr>
                    <tr>
                      <td><span class="float-right">Tgl<span class="white">_</span>lahir</span></td>
                      <td><span class="">{{ $kamerad->tempat_lahir }}, {{ (date("d M Y", strtotime($kamerad->tgl_lahir))) }}</span></td>
                    </tr>
                    <tr>
                      <td><span class="float-right">Kelamin</span></td>
                      <td><span class="">
                        @if ($kamerad->kelamin == "l")
                          Laki-laki
                          @else
                            Perempuan
                        @endif
                      </span></td>
                    </tr>
                    <tr>
                      <td><span class="float-right">Agama</span></td>
                      <td><span class="">{{ $kamerad->agama }}</span></td>
                    </tr>
                    <tr>
                      <td><span class="float-right">Gol darah</span></td>
                      <td><span class="">{{ $kamerad->gol_darah }}</span></td>
                    </tr>
                    <tr>
                      <td><span class="float-right">Kontak</span></td>
                      <td><span class="">{{ $kamerad->hape }}</span></td>
                    </tr>
                    <tr>
                      <td><span class="float-right">Email</span></td>
                      <td><span class="">{{ $kamerad->email }}</span></td>
                    </tr>

                  </table>

                </div>
                <div class="tab-pane fade" id="rubrik" role="tabpanel" aria-labelledby="rubrik-tab">
                  <br>
                  <canvas id="radar-chart-rubrik" width="400" height="400"></canvas>
                </div>
                <div class="tab-pane fade" id="isu" role="tabpanel" aria-labelledby="isu-tab">
                  <br>
                  <canvas id="radar-chart-isu" width="400" height="400"></canvas>
                </div>
                <div class="tab-pane fade show active" id="aktivitas" role="tabpanel" aria-labelledby="aktivitas-tab">
                  <br>
                  <ul class="list-unstyled activity-timeline">
                    @php
                      $n = 1;
                    @endphp
                    @foreach ($aktivitas as $akt)
                      @if ($n <= 100)
                      @if ($akt->meta != '')
                        <li>
                          <i class="activity-icon"></i>
                          <p>Menulis <span>{{ $akt->jenis }}</span>
                            berjudul
                            <a target="_blank" class="judul" href="{{ $akt->meta }}">
                              <b>{{ $akt->judul }}</b>
                            </a>
                            <span class="timestamp">
                              @if ($akt->day < 365)
                                {{ $akt->day }}
                                hari yang lalu
                              @elseif ($akt->day < 730)
                                1 tahun yang lalu
                              @elseif ($akt->day < 1450)
                                  2 tahun yang lalu
                                  @else
                                    sudah lama sekali
                              @endif
                            </span>
                          </p>
                        </li>
                        <hr>
                        @else
                          <li>
                            <i class="activity-icona"></i>
                            <p>Menjadi Pemantik <span>{{ $akt->jenis }}</span>
                              bertema
                              <a href="#" class="judul">
                                <b>{{ $akt->judul }}</b>
                              </a>
                              <span class="timestamp">
                                @if ($akt->day < 365)
                                  {{ $akt->day }}
                                  hari yang lalu
                                @elseif ($akt->day < 730)
                                  1 tahun yang lalu
                                @elseif ($akt->day < 1450)
                                    2 tahun yang lalu
                                    @else
                                      sudah lama sekali
                                @endif
                              </span>
                            </p>
                          </li>
                          <hr>
                      @endif
                      @endif
                      @php
                        $n++;
                      @endphp
                    @endforeach

                  </ul>
                </div>
              </div>
            </div>
          </div>
          <br>
        </div>
      </div>
    </div>
    <br>
  </div>
  <!-- end of mainbar -->
  <!--start of sidebar -->
  <div class="col-md-4" id="sideBar">
    <div class="card">
      <div class="card-body">
        <div class="container">
          <table class="table wid-reminder">
            <tr>
              <td class="no-border"><span class="">Terakhir menulis</span></td>
              <td class="no-border">
                <span class="counter">
                  @foreach ($aktivitas as $akt)
                    @if ($akt->meta != '')
                      {{ $akt->day }}
                      @break
                    @endif
                  @endforeach
                </span>
                <span class="ket-counter">hari yang lalu</span>
              </td>
            </tr>
            <tr>
              <td class=""><span class="">Terakhir diskusi</span></td>
              <td class="">
                <span class="counter">
                  @foreach ($aktivitas as $akt)
                    @if ($akt->meta == '')
                      {{ $akt->day }}
                      @break
                    @endif
                  @endforeach
                </span>
                <span class="ket-counter">hari yang lalu</span>
              </td>
            </tr>
          </table>
        </div>
      </div>
    </div>
    <br>
    <div class="card bg-pink">
      <div class="card-body">
        <div class="container">
          <h5>Rerata Tulisan Per Bulan</h5>
        </div>
      </div>
    </div>
    <br>
    <div class="card bg-pink">
      <div class="card-body">
        <div class="container">
          <h5>Posisi</h5>
        </div>
      </div>
    </div>
  <!-- end of sidebar -->
</div>

<!-- Modal Hapus Kamerad -->
<div class="modal fade" id="HapusAkun" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <br>
        <h6>
          Apakah Anda yakin ingin menghapus akun ini?
        </h6>
        <br>
        <button type="button" class="btn btn-secondary marg float-right" data-dismiss="modal">Batal</button>

        <form action="/kamerad/{{ $kamerad->nim }}" method="post">
          <input type="hidden" name="_method" value="delete">
          {{ csrf_field() }}
        <button type="submit" class="btn btn-danger marg float-right" value="delete">Ya, hapus</button>
        </form>

      </div>
    </div>
  </div>
</div>

<script src="{{ url('js/Chart.min.js') }}"></script>
<script>
var dataRubrik = {
  labels: [
    @foreach ($rubriks as $rubrik)
      @if ($rubrik->kode_rubrik != 0)
        "{{ $rubrik->nama_rubrik }}",
      @endif
    @endforeach
  ],
  datasets: [
    {
      label: "Konten",
      fill: true,
      backgroundColor: "rgba(250,108,0,0.6)",
      borderColor: "rgba(250,108,0)",
      pointBorderColor: "#fff",
      pointRadius: 3,
      data: [

        @php
          $a = 1;
          $b = 1;
        @endphp
        {{-- 9 itu representasi jumlah rubrik --}}
        @for ($i=$a; $i <= 9; $i++)
          @foreach ($statrubrik as $stat)
            @if ($stat->kode_rubrik == $i)
              {{ $stat->jumlah }},
              @php
              $b = 0;
              @endphp
            @endif
          @endforeach
          @if ($b != 0)
            0,
          @endif
          @php
            $n = $i + 1;
            $b = 1;
          @endphp
        @endfor

      ]
    }
  ]
};

var dataIsu = {
  labels: [
    @foreach ($isus as $isu)
      @if ($isu->kode_isu != 0)
        "{{ $isu->nama_isu }}",
      @endif
    @endforeach
  ],
  datasets: [
    {
      label: "Konten",
      display: "false",
      fill: true,
      backgroundColor: "rgba(255,193,13,0.6)",
      borderColor: "rgba(255,193,13)",
      pointBorderColor: "#fff",
      pointRadius: 3,
      data: [

        @php
          $a = 1;
          $b = 1;
        @endphp
        {{-- 9 itu representasi jumlah isu --}}
        @for ($i=$a; $i <= 10; $i++)
          @foreach ($statisu as $stat)
            @if ($stat->kode_isu == $i)
              {{ $stat->jumlah }},
              @php
              $b = 0;
              @endphp
            @endif
          @endforeach
          @if ($b != 0)
            0,
          @endif
          @php
            $n = $i + 1;
            $b = 1;
          @endphp
        @endfor

      ]
    }
  ]
};

var options = {
  responsive: true,
  maintainAspectRatio: true,
  scale: {
      ticks: {
          beginAtZero: true,
          max: 10,
          min: -1
      }
  }
};

new Chart(document.getElementById("radar-chart-rubrik"), {
    type: 'radar',
    data: dataRubrik,
    options: options
});

new Chart(document.getElementById("radar-chart-isu"), {
    type: 'radar',
    data: dataIsu,
    options: options
});
</script>

@endsection
