@extends('layout.main')

@section('title')
  Progreso | Banyak orang hanya menyambung hidup, kita harus juga mengisinya
@endsection

@section('content')

<div class="row">
  <!-- start of mainbar -->
  <div class="col-md-8" id="mainBar">
    {{-- <div class="card">
      <div class="card-body">
        <div class="container">
          <h4>Produk Jurnalistik</h4>
          <div class="progress capaian">
            <div class="progress-bar" style="width: 90%;">Hard News</div>
          </div>
          <div class="progress capaian">
            <div class="progress-bar" style="width: 20%;">Feature</div>
          </div>
          <div class="progress capaian">
            <div class="progress-bar" style="width: 20%;">Indepth</div>
          </div>
          <div class="progress capaian">
            <div class="progress-bar" style="width: 0%;">Investigasi</div>
          </div>
          <div class="progress capaian">
            <div class="progress-bar" style="width: 95%;">Kolom</div>
          </div>
          <div class="progress capaian">
            <div class="progress-bar" style="width: 40%;">Resensi</div>
          </div>
          <div class="progress capaian">
            <div class="progress-bar" style="width: 20%;">Infografis</div>
          </div>
          <div class="progress capaian">
            <div class="progress-bar" style="width: 10%;">Foto</div>
          </div>
        </div>
      </div>
    </div>
    <br>
    <div class="card">
      <div class="card-body">
        <div class="container">
          <h4>Kecenderungan Isu</h4>
          <canvas id="radarChart"></canvas>
        </div>
      </div>
    </div>
    <br>
    <div class="card">
      <div class="card-body">
        <div class="container">
          <h4>Aktivitas Terbaru</h4>
          <canvas id="radarChart"></canvas>
        </div>
      </div>
    </div>
    <br> --}}
    <h5>Halaman Profil Akun yang login</h5>

  </div>
  <!-- end of mainbar -->
  <!--start of sidebar -->
  {{-- <div class="col-md-4" id="sideBar">
    <div class="card">
      <div class="card-body">
        <div class="container">
          <h4>Target Mingguan</h4>
            <p>tes</p>
        </div>
      </div>
    </div>
    <br>
    <div class="card">
      <div class="card-body">
        <div class="container">
          <h4>Level Capaian</h4>
            <p>tes</p>
        </div>
      </div>
    </div>
    <br>
    <div class="card">
      <div class="card-body">
        <div class="container">
          <h4>Penghargaan</h4>
            <p>tes</p>
        </div>
      </div>
    </div>
    <br>
    <div class="card">
      <div class="card-body">
        <div class="container">
          <h4>Papan Skor</h4>
            <p>tes</p>
        </div>
      </div>
    </div>
  </div> --}}
  <!-- end of sidebar -->
</div>

@endsection
