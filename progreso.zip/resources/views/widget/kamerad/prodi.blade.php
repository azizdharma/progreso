@foreach ($widprodi as $prodi)

{ y: {{ $prodi->jumlah }}, label:" {{ $prodi->prodi }}" },

@endforeach
