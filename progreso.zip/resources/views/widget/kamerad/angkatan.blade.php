
<table class="table">
  <br>
  @php
    $kunci = 0;
  @endphp
  @foreach ($widangkatan as $angkatan)
    @if ($angkatan->angkatan == 0)

      @else
        @if ($kunci < 1)
          <tr>
            <td class="no-border"><span class="timestamp"><b>{{ $angkatan->angkatan }}</b></span></td>
            <td class="no-border"><span class="timestamp float-right">{{ $angkatan->jumlah }}</span> </td>
          </tr>
          @php
            $kunci++;
          @endphp
          @else
            <tr>
              <td class=""><span class="timestamp"><b>{{ $angkatan->angkatan }}</b></span></td>
              <td class=""><span class="timestamp float-right">{{ $angkatan->jumlah }}</span> </td>
            </tr>
        @endif

    @endif
  @endforeach

</table>
