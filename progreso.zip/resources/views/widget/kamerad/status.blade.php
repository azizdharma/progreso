
<table class="table">
  <br>
  @php
    $kunci = 0;
  @endphp
  @foreach ($widstatus as $status)
    @if ($kunci < 1)
          <tr>
            <td class="no-border"><span class="timestamp"><b>
                  @if ($status->status == 0)
                    <a href="/kamerad">Aktif</a>
                  @elseif ($status->status == 1)
                    <a href="/post">Post-struktur</a>
                  @elseif ($status->status == 2)
                    <a href="/alumni">Alumni</a>
                  @endif
                </b></span>
            </td>
            <td class="no-border"><span class="timestamp float-right">{{ $status->jumlah }}</span></td>
          </tr>
          @php
            $kunci++;
          @endphp
          @else
            <tr>
              <td class=""><span class="timestamp"><b>
                @if ($status->status == 0)
                  <a href="/kamerad">Aktif</a>
                @elseif ($status->status == 1)
                  <a href="/post">Post-struktur</a>
                @elseif ($status->status == 2)
                  <a href="/alumni">Alumni</a>
                @endif
                  </b></span>
              </td>
              <td class=""><span class="timestamp float-right">{{ $status->jumlah }}</span></td>
            </tr>
    @endif
  @endforeach

</table>
