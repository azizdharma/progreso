<br>
<table class="table">

  @foreach ($needs as $kamerad)

      <tr>

        <td class="align-middle fit">
          <a href="kamerad/{{ $kamerad->nim }}">
          <img src="img/{{ $kamerad->image }}" class="float-left img-circle" width="50px" height="50px">
          </a>
        </td>
        <td class="align-middle">
          <a href="kamerad/{{ $kamerad->nim }}">
          <span class="timestamp"><b>{{ $kamerad->panggilan }}</b></span>
        </a>
        </td>

        <td class="align-middle">
          <span class="timestamp"><b>{{ $kamerad->jumlah }} PX</b></span>
        </td>
      </tr>

  @endforeach
</table>
