@foreach ($widrubrik as $rubrik)
  { y: {{ $rubrik->jumlah }}, label:" {{ $rubrik->nama_rubrik }}" },
@endforeach
