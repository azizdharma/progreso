@foreach ($widdiskusi as $diskusi)
  { y: {{ $diskusi->jumlah }}, label:" {{ $diskusi->jenis_diskusi }}" },
@endforeach
