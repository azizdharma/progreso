@php
  $n = 1;
@endphp
@foreach ($widgrafik as $grafik)
  @for ($i=$n; $i <= $grafik->month; $i++)
    @if ($grafik->month == $i)
      { x: new Date(2018, {{ $grafik->month }}), y: {{ $grafik->jumlah }} },
    @else
      { x: new Date(2018, {{ $i }}), y: 0 },
    @endif
    @php
      $n = $i + 1;
    @endphp
  @endfor
@endforeach
