<br>
<table class="table">
  @php
    $n = 0;
  @endphp
  @foreach ($widpemantik as $pemantik)
    @if ($n < 1)
      <tr>
        <td class="align-middle fit no-border">
          <a href="pemantik/{{ $pemantik->nim }}">
          <img src="img/{{ $pemantik->image }}" class="float-left img-circle" width="50px" height="50px">
          </a>
        </td>
        <td class="align-middle no-border">
          <a href="pemantik/{{ $pemantik->nim }}">
          <span class="timestamp"><b>{{ $pemantik->panggilan }}</b></span>
        </a>
        </td>

        <td class="align-middle no-border">
          <span class="timestamp"><b>{{ $pemantik->jumlah }} PX</b></span>
        </td>
      </tr>
      @php
        $n++;
      @endphp
      @else
        <tr>
          <td class="align-middle fit">
            <a href="pemantik/{{ $pemantik->nim }}">
            <img src="img/{{ $pemantik->image }}" class="float-left img-circle" width="50px" height="50px">
            </a>
          </td>
          <td class="align-middle">
            <a href="pemantik/{{ $pemantik->nim }}">
            <span class="timestamp"><b>{{ $pemantik->panggilan }}</b></span>
          </a>
          </td>

          <td class="align-middle">
            <span class="timestamp"><b>{{ $pemantik->jumlah }} PX</b></span>
          </td>
        </tr>
    @endif
  @endforeach
</table>
