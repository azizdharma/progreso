@foreach ($widgrafik as $grafik)
  @for ($i=$n; $i <= $grafik->week; $i++)
    @if ($grafik->week == $i)
      { label: "Minggu {{ $grafik->week }}", y: {{ $grafik->jumlah }} },
    @else
      { label: "Minggu {{ $i }}", y: 0 },
    @endif
    @php
      $n = $i + 1;
    @endphp
  @endfor
@endforeach
