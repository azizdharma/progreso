@foreach ($widisu as $isu)

{ y: {{ $isu->jumlah }}, label:" {{ $isu->nama_isu }}" },

@endforeach
