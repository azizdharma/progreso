<?php $__currentLoopData = $widrubrik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rubrik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  { y: <?php echo e($rubrik->jumlah); ?>, label:" <?php echo e($rubrik->nama_rubrik); ?>" },
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
