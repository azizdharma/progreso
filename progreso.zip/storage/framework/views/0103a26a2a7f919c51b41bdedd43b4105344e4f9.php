<?php $__env->startSection('content'); ?>
<div class="row">
  <!-- start of mainbar -->
  <div class="col-md-8" id="mainBar">
    <div class="card">
      <div class="card-body">
        <div class="container">
          <br>
          <h3>Aktivitas</h3>
          <br> <br>
          <ul class="list-unstyled activity-timeline">
            <?php $__currentLoopData = $aktivitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $akt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($akt->meta != '' ): ?>
                <li>
                  <div class="row">
                    <div class="col-md-1">
                      <a href="kamerad/<?php echo e($akt->nim); ?>">
                        <img src="img/<?php echo e($akt->image); ?>" alt="Avatar" class="rounded-2 pull-left avatar" width="50px" height="50px">
                      </a>
                    </div>
                    <div class="col-md-10 pas">
                      <span class="">
                        <?php echo e($akt->panggilan); ?> menulis <code class="biru"><?php echo e($akt->jenis); ?></code> berjudul
                        <a class="alert-link" target="_blank" href="<?php echo e($akt->meta); ?>"> <?php echo e($akt->judul); ?></a>.
                      </span>
                      <span class="timestamp ">
                        <i class="activity-icon"></i>
                        <?php if($akt->day >= 1): ?>
                          <?php echo e($akt->day); ?> hari yang lalu.
                        <?php elseif($akt->day <= 0): ?>
                          <?php echo e($akt->day); ?> hari lagi.
                          <?php else: ?>
                            Hari ini.
                        <?php endif; ?>
                      </span>
                    </div>
                  </div>
                </li>
                <hr>
                <?php else: ?>
                  <li>
                    <div class="row">
                      <div class="col-md-1">
                        <a href="kamerad/<?php echo e($akt->nim); ?>">
                          <img src="img/<?php echo e($akt->image); ?>" alt="Avatar" class="rounded-2 pull-left avatar" width="50px" height="50px">
                        </a>
                      </div>
                      <div class="col-md-10 pas">
                        <span class="">
                          <?php echo e($akt->panggilan); ?> menjadi pemantik <code class="hijau"><?php echo e($akt->jenis); ?></code> bertema
                          <a class="alert-link"><?php echo e($akt->judul); ?></a>.
                        </span>
                        <span class="timestamp">
                          <i class="activity-icona"></i>
                          <?php if($akt->day >= 1): ?>
                            <?php echo e($akt->day); ?> hari yang lalu.
                          <?php elseif($akt->day <= 0): ?>
                            <?php echo e($akt->day); ?> hari lagi.
                            <?php else: ?>
                              Hari ini.
                          <?php endif; ?>
                        </span>
                      </div>
                  </div>
                </li>
                <hr>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($aktivitas) < 11): ?>
              <li>
                <div class="row">
                  <div class="col-md-12">
                    <center><a href="/aktivitas-full" role="button" class="btn btn-success rounded col-md-3 tt"> <b class="putih"> SELENGKAPNYA </b></a></center>
                  </div>
                </div>
              </li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </div>
    <br>
  </div>
  <!-- end of mainbar -->
  <!--start of sidebar -->

  <!-- end of sidebar -->
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>