<?php
  $n = 1;
?>
<?php $__currentLoopData = $widgrafik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grafik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php for($i=$n; $i <= $grafik->month; $i++): ?>
    <?php if($grafik->month == $i): ?>
      { x: new Date(2018, <?php echo e($grafik->month); ?>), y: <?php echo e($grafik->jumlah); ?> },
    <?php else: ?>
      { x: new Date(2018, <?php echo e($i); ?>), y: 0 },
    <?php endif; ?>
    <?php
      $n = $i + 1;
    ?>
  <?php endfor; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
