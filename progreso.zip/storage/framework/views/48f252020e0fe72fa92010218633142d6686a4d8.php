
<table class="table">
  <br>
  <?php
    $kunci = 0;
  ?>
  <?php $__currentLoopData = $widangkatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $angkatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($angkatan->angkatan == 0): ?>

      <?php else: ?>
        <?php if($kunci < 1): ?>
          <tr>
            <td class="no-border"><span class="timestamp"><b><?php echo e($angkatan->angkatan); ?></b></span></td>
            <td class="no-border"><span class="timestamp float-right"><?php echo e($angkatan->jumlah); ?></span> </td>
          </tr>
          <?php
            $kunci++;
          ?>
          <?php else: ?>
            <tr>
              <td class=""><span class="timestamp"><b><?php echo e($angkatan->angkatan); ?></b></span></td>
              <td class=""><span class="timestamp float-right"><?php echo e($angkatan->jumlah); ?></span> </td>
            </tr>
        <?php endif; ?>

    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
