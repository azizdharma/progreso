<?php $__env->startSection('title'); ?>
  Progreso | Banyak orang hanya menyambung hidup, kita harus juga mengisinya
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <!-- start of mainbar -->
  <div class="col-md-8" id="mainBar">
    
    <h5>Halaman Profil Akun yang login</h5>

  </div>
  <!-- end of mainbar -->
  <!--start of sidebar -->
  
  <!-- end of sidebar -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>