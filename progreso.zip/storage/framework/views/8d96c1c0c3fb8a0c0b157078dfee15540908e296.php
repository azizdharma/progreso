<?php $__env->startSection('content'); ?>
<div class="row">
  <!-- start of mainbar -->
  <div class="col-md-8" id="mainBar">
    <div class="card ">
      <div class="card-body">
        <div class="container">
          <br>
          <div class="row">
            <div class="col-md-7">
            <?php if($totem == 'aktif'): ?>
              <h3>Kamerad</h3>
            <?php elseif($totem == 'post'): ?>
              <h3>Post-Struktur</h3>
            <?php elseif($totem == 'alumni'): ?>
                <h3>Alumni</h3>
            <?php endif; ?>

            </div>
            <div class="col-md-5">
              <a role="button" href="kamerad/tambah" class="btn btn-success rounded float-right"><b class="putih">&nbsp;&nbsp;TAMBAH&nbsp;&nbsp;</b></a>
            </div>
          </div>
          <br>
          <br>
          
          <div class="row">

          <?php $__currentLoopData = $kamerads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kamerad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($kamerad->nama != "Admin"): ?>
              <div class="col-md-4">
                <div class="card profilecards">
                  <?php if($kamerad->angkatan < (date("Y")-2)): ?>
                    <div class="card-header header-asoy bg-black rounded-top">
                      <br> <br>
                    </div>
                  <?php elseif($kamerad->angkatan < (date("Y")-1)): ?>
                    <div class="card-header header-asoy bg-orange rounded-top">
                      <br> <br>
                    </div>
                  <?php elseif($kamerad->angkatan < (date("Y"))): ?>
                    <div class="card-header header-asoy bg-green rounded-top">
                      <br> <br>
                    </div>
                  <?php else: ?>
                    <div class="card-header header-asoy bg-pink rounded-top">
                      <br> <br>
                    </div>
                  <?php endif; ?>
                  <div class="card-body kam-kam rounded-bottom">
                    <center>
                    <a href="/kamerad/<?php echo e($kamerad->nim); ?>" class="ProfileCard-avatarLink">
                      <img src="img/<?php echo e($kamerad->image); ?>" class="float-left img-circle" width="80px" height="80px" alt="<?php echo e($kamerad->image); ?>">
                    </a>
                    <h6 class="card-title"><b><?php echo e($kamerad->nama); ?></b></h6>
                    <span class="badge">XP <?php echo e($kamerad->angkatan); ?></span>
                  </center>
                  </div>
                </div>
              </div>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
          <br>
        </div>
      </div>
    </div>
    <br>
  </div>
  <!-- end of mainbar -->
  <!--start of sidebar -->
 <div class="col-md-4" id="sideBar">
   <div class="card bg-pink">
     <div class="card-body">
       <div class="container">
         <h5>Progress Bulan Ini</h5>
         <span class="count-top"></span>
       </div>
     </div>
   </div>
   <br>
   <div class="card bg-pinks">
     <div class="card-body">
       <div class="container">
         <h5>Needs Treatments</h5>

       </div>
     </div>
   </div>
   <br>
   <div class="card">
     <div class="card-body">
       <div class="container">
         <h5>Anggota Terdaftar</h5>
         <?php echo $__env->make('widget.kamerad.status', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       </div>
     </div>
   </div>
   <br>
   <div class="card">
     <div class="card-body">
       <div class="container">
         <h5>Sebaran Angkatan Aktif</h5>
         <?php echo $__env->make('widget.kamerad.angkatan', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       </div>
     </div>
   </div>
   <br>
    <div class="card">
      <div class="card-body">
        <div class="container">
          <h5>Sebaran Prodi Anggota Aktif</h5>
          <div id="chartContainer3" style="height: 250px; width: 100%;"> </div>
        </div>
      </div>
    </div>
    <br>
  </div>

</div>
<script>
window.onload = function () {

// var chart1 = new CanvasJS.Chart("chartContainer1", {
// 	animationEnabled: true,
// 	axisX:{
// 		valueFormatString: "DD MMM",
//
//     labelFontColor: "white",
// 		lineColor: "#d8d8d8"
// 	},
// 	axisY: {
// 		includeZero: false,
// 		gridColor: "#d8d8d8",
//     labelFontColor: "#9e9e9e",
// 		lineColor: "#d8d8d8"
// 	},
// 	data: [{
// 		type: "line",
// 		color: "#ffb905",
//     markerSize: 0,
// 		dataPoints: [
//
//       include('widget.terbitan.grafik')
//
// 		]
// 	}]
// });
// var chart2 = new CanvasJS.Chart("chartContainer2", {
//   animationEnabled: true,
//   axisX:{
//     interval: 1,
//     gridColor: "#d8d8d8",
//     labelFontColor: "#9e9e9e",
//     lineColor: "#d8d8d8"
//   },
//   axisY:{
//     labelMaxWidth: -1,
//     gridColor: "#d8d8d8",
//     labelFontColor: "white",
//     lineColor: "#d8d8d8"
//   },
//   data: [{
//     type: "bar",
//     name: "companies",
//     color: "#27a9e6",
// 		toolTipContent: "<b>{label}:</b> {y} terbitan",
//     dataPoints: [
//
//       include('widget.terbitan.poprubrik')
//
//     ]
//   }]
// });
var chart3 = new CanvasJS.Chart("chartContainer3", {
	animationEnabled: true,
	data: [{
		type: "doughnut",
		startAngle: 180,
		//innerRadius: 60,
		// indexLabelFontSize: 2,
		indexLabel: "{label}",
		toolTipContent: "<b>{label}:</b> {y} (#percent%)",
		dataPoints: [

      <?php echo $__env->make('widget.kamerad.prodi', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    ]
	}]
});

// chart1.render();
// chart2.render();
chart3.render();
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>