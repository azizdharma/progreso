<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <?php echo $__env->make('layout.parts.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </head>
  <body>
    <?php echo $__env->make('layout.parts.navlogin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main role="main" class="container">
      <div class="col-md-8 bg-pink">
      tes
      </div>
      <div class="row">
        <div class="col-md-12">
          <br><br><br>
        </div>
      </div>
    </main>
    <?php echo $__env->make('layout.parts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </body>
</html>
