<?php $__currentLoopData = $widprodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

{ y: <?php echo e($prodi->jumlah); ?>, label:" <?php echo e($prodi->prodi); ?>" },

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
