<?php $__env->startSection('content'); ?>

<div class="row">
  <!-- start of mainbar -->
  <div class="col-8" id="mainBar">
    <div class="card">
      <div class="card-body">
        <div class="container">
          <h4>Detail Terbitan</h4>

          <p>Ini detail terbitan untuk pos dengan id <?php echo e($id); ?></p>

        </div>
      </div>
    </div>
    <br>
  </div>
  <!-- end of mainbar -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>