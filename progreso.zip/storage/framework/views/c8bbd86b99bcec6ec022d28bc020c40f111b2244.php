<br>
<table class="table">
  <?php
    $n = 0;
  ?>
  <?php $__currentLoopData = $widpemantik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pemantik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($n < 1): ?>
      <tr>
        <td class="align-middle fit no-border">
          <a href="pemantik/<?php echo e($pemantik->nim); ?>">
          <img src="img/<?php echo e($pemantik->image); ?>" class="float-left img-circle" width="50px" height="50px">
          </a>
        </td>
        <td class="align-middle no-border">
          <a href="pemantik/<?php echo e($pemantik->nim); ?>">
          <span class="timestamp"><b><?php echo e($pemantik->panggilan); ?></b></span>
        </a>
        </td>

        <td class="align-middle no-border">
          <span class="timestamp"><b><?php echo e($pemantik->jumlah); ?> PX</b></span>
        </td>
      </tr>
      <?php
        $n++;
      ?>
      <?php else: ?>
        <tr>
          <td class="align-middle fit">
            <a href="pemantik/<?php echo e($pemantik->nim); ?>">
            <img src="img/<?php echo e($pemantik->image); ?>" class="float-left img-circle" width="50px" height="50px">
            </a>
          </td>
          <td class="align-middle">
            <a href="pemantik/<?php echo e($pemantik->nim); ?>">
            <span class="timestamp"><b><?php echo e($pemantik->panggilan); ?></b></span>
          </a>
          </td>

          <td class="align-middle">
            <span class="timestamp"><b><?php echo e($pemantik->jumlah); ?> PX</b></span>
          </td>
        </tr>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
