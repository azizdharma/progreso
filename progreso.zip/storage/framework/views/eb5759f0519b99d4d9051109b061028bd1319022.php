<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <?php echo $__env->make('layout.parts.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </head>
  <body>
    <?php echo $__env->make('layout.parts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main role="main" class="container">
      <?php echo $__env->yieldContent('content'); ?>
    </main>
    <?php echo $__env->make('layout.parts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </body>
</html>
