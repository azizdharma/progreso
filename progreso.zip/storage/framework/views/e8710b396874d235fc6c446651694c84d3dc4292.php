<?php $__currentLoopData = $widgrafik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grafik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php for($i=$n; $i <= $grafik->week; $i++): ?>
    <?php if($grafik->week == $i): ?>
      { label: "Minggu <?php echo e($grafik->week); ?>", y: <?php echo e($grafik->jumlah); ?> },
    <?php else: ?>
      { label: "Minggu <?php echo e($i); ?>", y: 0 },
    <?php endif; ?>
    <?php
      $n = $i + 1;
    ?>
  <?php endfor; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
