<?php $__env->startSection('content'); ?>
<div class="row">
  <!-- start of mainbar -->
  <div class="col-8" id="mainBar">
    <div class="card">
      <div class="card-body">
        <div class="container">
          <br>
          <div class="row">
            <div class="col-7">
              <h3>Edit Terbitan</h3>
            </div>
            <div class="col-5">
              <form>
              <button type="button" class="btn btn-success rounded float-right"><b>&nbsp;SIMPAN&nbsp;</b></button>
            </div>
          </div>
          <br><br><br>

            <div class="form-group row">
              <label for="inputJudul" class="col-sm-3 col-form-label kanan">Judul</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" id="inputJudul" placeholder="Judul" value="<?php echo e($konten->judul_konten); ?>">
              </div>
            </div>
            <div class="form-group row">
              <label for="inputTautan" class="col-sm-3 col-form-label kanan">Tautan</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" id="inputTautan" placeholder="Tautan" value="<?php echo e($konten->link); ?>">
              </div>
            </div>
            <div class="form-group row">
              <label for="inputTanggal" class="col-sm-3 col-form-label kanan">Tanggal</label>
              <div class="col-sm-8">
                <input type="date" class="form-control custom-select col-sm-6" id="inputTautan" placeholder="Tautan" value="<?php echo e($konten->tgl_konten); ?>">
              </div>
            </div>
            <div class="form-group row">
              <label for="inputRedaktur" class="col-sm-3 col-form-label kanan">Redaktur</label>
              <div class="col-sm-8">
                <select id="inputRedaktur" class="form-control custom-select mr-sm-2 col-sm-6">
                  <option selected><?php echo e($konten->redaktur); ?></option>
                  <option value="1">One</option>
                  <option value="2">Two</option>
                  <option value="3">Three</option>
                </select>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputRubrik" class="col-sm-3 col-form-label kanan">Rubrik</label>
              <div class="col-sm-8">
                <select id="inputRubrik" class="form-control custom-select mr-sm-2 col-sm-6">
                  <option selected><?php echo e($konten->kode_rubrik); ?></option>
                  <option value="1">One</option>
                  <option value="2">Two</option>
                  <option value="3">Three</option>
                </select>
              </div>
            </div>
            <div class="form-group row">
              <label for="inputIsu" class="col-sm-3 col-form-label kanan">Isu</label>
              <div class="col-sm-8">
                <select id="inputIsu" class="form-control custom-select mr-sm-2 col-sm-6">
                  <option selected><?php echo e($konten->kode_isu); ?></option>
                  <option value="1">One</option>
                  <option value="2">Two</option>
                  <option value="3">Three</option>
                </select>
              </div>
            </div>
            <br>
            <div class="form-group row">
              <label for="inputIsu" class="col-sm-3 col-form-label kanan"></label>
              <div class="col-sm-8">
                <button type="button" class="btn btn-sm btn-danger rounded"><b>&nbsp;&nbsp;HAPUS&nbsp;&nbsp;</b></button>
              </div>
            </div>
          </form>
          <br>
        </div>
      </div>
    </div>
    <br>
  </div>
  <!-- end of mainbar -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>