<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <?php echo $__env->make('layout.parts.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </head>
  <body class="bg-white">
    <?php echo $__env->make('layout.parts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main role="main" class="container">
<div class="row">
  <!-- start of mainbar -->
  <div class="col-md-2">
    <div class="sosial float-right sticky">
      <br><br><br>
      <img src="<?php echo e(url('img/heat.png')); ?>" alt="runtutan">
    </div>
  </div>
  <div class="col-md-8" id="mainBar">
    <div class="card">
      <div class="card-body">
        <div class="container art">
          <h1><i>Manifesto Progreso</i></h1>
          <br><br>
          <p class="article">
            <span class="firstcharacter">K</span>ausetujui arsip memperpanjang ingatan. Tapi kau sendiri lupa mencatat apa yg kaulakukan ...” Begitulah Muhidin M. Dahlan menulis kegemasannya terhadap orang-orang yang acap kali ikut mengangguk soal pentingnya kerja-kerja pengarsipan, tapi sama sekali tak terlibat. Bahkan untuk dirinya sendiri. Dalam &#8220;<a target="_blank" href="http://akubuku.blogspot.com/2013/02/arsip-sepenting-apa.html"><u class="black">Arsip, Sepenting Apa?</u></a>&#8221; Muhidin seperti marah-marah karena kejadian dan perkataan orang-orang terhadap kerja pengarsipan acap kali tak lebih dari sekadar paradoks.</p>
          <p class="article">Sebagai seorang&#8211;&#8211;sebut saja&#8211;&#8211;maniak arsip, Muhidin tentu sulit ditiru. Maka, aplikasi ini tidak hendak menjadikan siapa pun penggunanya menjadi Muhidin. Aplikasi ini hanyalah sebuah usaha mematerialkan perbincangan-perbincangan kecil di LPM EKSPRESI terkait dengan bagaimana mengukur kemampuan, persistensi, dan tekad dalam pembelajaran kerja-kerja jurnalistik. </p>
          <p class="article">Kredo agar tidak cepat puas dengan proses belajar yang, memang tidak akan mudah, tapi jelas membangun!</p>
          <p class="article">Sebagai sebuah hasil materialisasi atas konsep, tentu aplikasi tidak akan mutlak berdiri sendiri. Ia hadir dengan cara pikir yang berjalan sehari-hari di kepala manusia-manusia EKSPRESI. Sayangnya, konsep-konsep tentang pengembangan diri itu tidak mudah dimaterialkan. Sebagian dari konsep itu membutuhkan pengamatan dan perasaan yang tentu tidak dimiliki oleh aplikasi ini. Maka dari itu, salah besar jika menganggap aplikasi ini adalah sebuah hal yang betul-betul mampu membaca perkembangan belajar <i>an sich</i>.</p>
          <p class="article">Aplikasi ini hanyalah sistem pendukung dari serangkaian cara melihat perkembangan individu-individu di EKSPRESI. Ia tidak akan memberitahumu siapa yang jenius pun siapa yang berotak udang. Ia juga tak akan memberi tahu siapa yang punya keberanian bak seorang wartawan perang pun siapa yang menjadi pengecut bak wartawan bodrek. </p>
          <p class="article">Meski begitu, ia tahu betul bagaimana mengapresiasi siapa saja yang menolak menjadi pemalas! Boleh dikata, aplikasi ini bekerja dengan logika &#8220;Kau boleh jadi apa pun, kecuali pemalas&#8221;, meski deskripsi atas &#8220;apa pun&#8221; di sini tidak seliar apa yang ada di kepalamu.</p>
          <p class="article">Ia mendeskripsikan &#8220;apa pun&#8221; dalam koridor ekosistem akademik pers mahasiswa yang: membahas tema apa saja, dengan cara apa saja. Menjadi seorang pengusung khilafah ataupun anarkis bukanlah sebuah masalah bagi deskripsi &#8220;apa pun&#8221; di sini. Atau menjadi pengulik tenaga kendali fuzzy atau penyintas kekerasan seksual atau pengagum <i>Game of Thrones</i> berikut budaya populer yang mengiringinya&#8211;&#8211;selama itu dialektis dan bisa dipertanggungjawabkan. Dari setiap kemungkinan-kemungkinan di dalam &#8220;apa pun&#8221; itu hanyalah pemalas yang diharamkan. Begitulah kira-kira moralitas aplikasi ini dibentuk.</p>
          <p class="article">Seseorang pernah berbicara berbusa-busa tentang iklim belajar yang tidak kondusif di organisasi tapi tak pernah tahu benar bagaimana dinamika belajar setiap orang di EKSPRESI. Ia hanya menerka-nerka dengan standar yang ternyata berbeda dari kawan-kawan di sampingnya. Maka, keresahan soal iklim belajar&#8211;&#8211;sebut saja begitu&#8211;&#8211;sulit menjadi keresahan bersama. Meski tidak betul-betul memberikan jawaban, aplikasi ini berusaha menyajikan bagaimana kondisi (secara kuantitatif) naik-turunnya progres belajar individu-individu di EKSPRESI. Harapannya, tentu bisa memberikan sumbangsih bagi pembacaan situasi dan kondisi tentang semangat belajar &#8220;menjadi jurnalis&#8221; di lembaga pers mahasiswa.</p>
          <p class="article">Ketika membaca sebuah buku, seseorang akan sulit memahami isi jika ia tidak menaruh skeptisisme di depan kelopak matanya. Begitu juga dengan aplikasi ini. Data demi data diolah menjadi informasi yang diharapkan dibaca dengan sebuah pertanyaan: Mengapa bisa jadi seperti ini? Apa yang terjadi dengan si A? Mengapa si B bisa begini? Bagaimana mungkin si C bisa seperti itu? dst. Maka dari itu, membuat informasi yang didapat sebagai bahan atas pesta pertanyaan adalah sebetul-betulnya semangat aplikasi ini. Mari berpesta!</p>
        </div>
      </div>
    </div>
    <br>
  </div>

  <!-- end of mainbar -->
  <!--start of sidebar -->
  <div class="col-md-4" id="sideBar">
  </div>

</div>

</main>
<?php echo $__env->make('layout.parts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
