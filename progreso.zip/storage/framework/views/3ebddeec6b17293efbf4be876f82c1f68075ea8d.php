<?php $__currentLoopData = $widisu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

{ y: <?php echo e($isu->jumlah); ?>, label:" <?php echo e($isu->nama_isu); ?>" },

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
