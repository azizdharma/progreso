<nav class="navbar navbar-expand-md navbar-dark bg-progreso fixed-top">
  <div class="container">
    <a class="navbar-brand" href="/">
      <img src="<?php echo e(url('img/logo-progreso.png')); ?>" alt="">
    </a>
    <form class="form-inline my-2 my-lg-0 float-right">
      <input type="text" class="form-control col-md-4 pas float-right" name="nim" value="" placeholder="NIM">
      <input type="password" class="form-control col-md-3 pas" name="password" value="" placeholder="Password">
      <button type="button btn" name="button" class="btn btn-warning putih align-middle col-md-2 rounded pas"> <b>MASUK</b>  </button>
    </form>
  </div>
</nav>
