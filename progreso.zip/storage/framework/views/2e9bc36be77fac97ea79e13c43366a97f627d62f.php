<?php $__env->startSection('content'); ?>
<div class="row">
  <!-- start of mainbar -->
  <div class="col-8" id="mainBar">
    <div class="card">
      <div class="card-body">
        <div class="container">
          <br>
          <h3>Tambah Kamerad</h3>
          <br>

          <form action="/kamerad" method="post">
          <input type="hidden" name="_method" value="POST">
          <?php echo e(csrf_field()); ?>


            <ul class="nav nav-tabs" id="myTab" role="tablist">
              <li class="nav-item">
                <a class="nav-link active" id="status-tab" data-toggle="tab" href="#status" role="tab" aria-controls="basic" aria-selected="true">Status</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="basic-tab" data-toggle="tab" href="#basic" role="tab" aria-controls="basic" aria-selected="true">Dasar</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="kontak-tab" data-toggle="tab" href="#kontak" role="tab" aria-controls="kontak" aria-selected="true">Kontak</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="foto-tab" data-toggle="tab" href="#foto" role="tab" aria-controls="foto" aria-selected="true">Foto</a>
              </li>
            </ul>

            <div class="tab-content" id="myTabContent">
              <div class="tab-pane fade show active" id="status" role="tabpanel" aria-labelledby="status-tab">
                <br>
                <div class="form-group row">
                  <label for="inputGambar" class="col-sm-3 col-form-label kanan">NIM *</label>
                  <div class="col-sm-8">
                    <input type="text" class="form-control" name="nim" placeholder="NIM" required>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inpuPassword" class="col-sm-3 col-form-label kanan">Password *</label>
                  <div class="col-sm-8">
                    <input type="password" class="form-control col-sm-6" name="password" placeholder="Password" required>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputprodi" class="col-sm-3 col-form-label kanan">Program studi</label>
                  <div class="col-sm-8">
                    <select name="kode_prodi" class="form-control custom-select mr-sm-2 col-sm-8">
                      <?php $__currentLoopData = $prodis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          <option value="<?php echo e($prodi->kode_prodi); ?>"><?php echo e($prodi->prodi); ?></option>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputAngkatan" class="col-sm-3 col-form-label kanan">Angkatan EKSPRESI</label>
                  <div class="col-sm-8">
                    <select name="angkatan" class="form-control custom-select mr-sm-2 col-sm-6" required>
                      <?php
                        $angkatans = array("2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020")
                      ?>
                      <?php $__currentLoopData = $angkatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $angkatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          <option value="<?php echo e($angkatan); ?>"><?php echo e($angkatan); ?></option>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputAngkatan" class="col-sm-3 col-form-label kanan">Status</label>
                  <div class="col-sm-8">
                    <select name="status" class="form-control custom-select mr-sm-2 col-sm-6">

                          <option selected value="0">Aktif</option>
                          <option value="1">Post-struktur</option>
                          <option value="2">Alumni</option>

                    </select>
                  </div>
                </div>
              </div>
              <div class="tab-pane fade" id="basic" role="tabpanel" aria-labelledby="basic-tab">
                <br>
                <div class="form-group row">
                  <label for="inputNama" class="col-sm-3 col-form-label kanan">Nama *</label>
                  <div class="col-sm-8">
                    <input type="text" class="form-control" name="nama" placeholder="Nama" required>
                    <div class="invalid-feedback">
                      Please provide a valid zip.
                    </div>

                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputPanggilan" class="col-sm-3 col-form-label kanan">Panggilan</label>
                  <div class="col-sm-7">
                    <input type="text" class="form-control" name="panggilan" placeholder="Panggilan">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputTempatLahir" class="col-sm-3 col-form-label kanan">Tempat, Tgl lahir</label>
                  <div class="col-sm-3">
                    <input type="text" class="form-control" name="tempat_lahir" placeholder="Tempat lahir">
                  </div>
                  <div class="col-sm-4">
                    <input type="date" class="form-control custom-select" name="tgl_lahir" placeholder="Tanggal lahir" >
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputKelamin" class="col-sm-3 col-form-label kanan">Jenis kelamin</label>
                  <div class="col-sm-8">
                    <select name="kelamin" class="form-control custom-select mr-sm-2 col-sm-6">

                          <option selected value="l">Laki-laki</option>
                          <option value="p">Perempuan</option>

                    </select>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputAgama" class="col-sm-3 col-form-label kanan">Agama</label>
                  <div class="col-sm-8">
                    <select name="agama" class="form-control custom-select mr-sm-2 col-sm-6">
                      <?php
                        $agamas = array("Islam", "Kristen", "Katholik", "Budha", "Hindu", "Konghucu", "Kepercayaan")
                      ?>
                      <?php $__currentLoopData = $agamas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          <option value="<?php echo e($agama); ?>"><?php echo e($agama); ?></option>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputGoldar" class="col-sm-3 col-form-label kanan">Golongan Darah</label>
                    <div class="col-sm-8">
                      <select name="gol_darah" class="form-control custom-select mr-sm-2 col-sm-2">
                        <?php
                          $gol_darah = array("A", "B", "AB", "O")
                        ?>
                        <?php $__currentLoopData = $gol_darah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $darah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option value="<?php echo e($darah); ?>"><?php echo e($darah); ?></option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                </div>
              </div>

              <div class="tab-pane fade" id="kontak" role="tabpanel" aria-labelledby="kontak-tab">
                <br>
                <div class="form-group row">
                  <label for="inputAlamatasal" class="col-sm-3 col-form-label kanan">Alamat asal *</label>
                  <div class="col-sm-8">
                    <textarea type="text" required class="form-control col-sm-8" name="alamat_asal" placeholder="Alamat asal"></textarea>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputAlamatyogya" class="col-sm-3 col-form-label kanan">Alamat di Yogya</label>
                  <div class="col-sm-8">
                    <textarea type="text" class="form-control col-sm-8" name="alamat_yogya" placeholder="Alamat asal"></textarea>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputHape" class="col-sm-3 col-form-label kanan">Kontak</label>
                  <div class="col-sm-8">
                    <input type="text" class="form-control col-sm-6" name="hape" placeholder="Hape">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputEmail" class="col-sm-3 col-form-label kanan">Email</label>
                  <div class="col-sm-8">
                    <input type="text" class="form-control col-sm-6" name="email" placeholder="Email" >
                  </div>
                </div>
              </div>

              <div class="tab-pane fade" id="foto" role="tabpanel" aria-labelledby="foto-tab">
                <br><br>
                <div class="form-group row">
                  <label for="submit" class="col-sm-2 col-form-label kanan"></label>
                  <div class="col-sm-8">
                    <input type="file" class="" name="image" placeholder="image">
                    <br><br>
                    <p>Pastikan form dengan tanda bintang (*) terisi untuk bisa mendaftar.</p>
                  </div>
                </div>

                <br>
                <div class="form-group row">
                  <label for="submit" class="col-sm-2 col-form-label kanan"></label>
                  <div class="col-sm-8">
                    <button type="submit" name="submit" value="create" class="btn btn-success rounded "><b>&nbsp;DAFTAR&nbsp;</b></button>
                  </div>
                </div>
              </div>
            </div>
          </form>
          <br>
        </div>
      </div>
    </div>
    <br>
  </div>
  <!-- end of mainbar -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>