
<table class="table">
  <br>
  <?php
    $kunci = 0;
  ?>
  <?php $__currentLoopData = $widstatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($kunci < 1): ?>
          <tr>
            <td class="no-border"><span class="timestamp"><b>
                  <?php if($status->status == 0): ?>
                    <a href="/kamerad">Aktif</a>
                  <?php elseif($status->status == 1): ?>
                    <a href="/post">Post-struktur</a>
                  <?php elseif($status->status == 2): ?>
                    <a href="/alumni">Alumni</a>
                  <?php endif; ?>
                </b></span>
            </td>
            <td class="no-border"><span class="timestamp float-right"><?php echo e($status->jumlah); ?></span></td>
          </tr>
          <?php
            $kunci++;
          ?>
          <?php else: ?>
            <tr>
              <td class=""><span class="timestamp"><b>
                <?php if($status->status == 0): ?>
                  <a href="/kamerad">Aktif</a>
                <?php elseif($status->status == 1): ?>
                  <a href="/post">Post-struktur</a>
                <?php elseif($status->status == 2): ?>
                  <a href="/alumni">Alumni</a>
                <?php endif; ?>
                  </b></span>
              </td>
              <td class=""><span class="timestamp float-right"><?php echo e($status->jumlah); ?></span></td>
            </tr>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
