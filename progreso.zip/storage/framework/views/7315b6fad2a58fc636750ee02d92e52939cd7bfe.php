<!-- Modal Hapus Kamerad -->
<div class="modal fade" id="HapusAkun" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <br>
        <h6>
          Apakah Anda yakin ingin menghapus akun ini?
        </h6>
        <br>
        <button type="button" class="btn btn-secondary marg float-right" data-dismiss="modal">Batal</button>

        <form action="/kamerad/<?php echo e($kamerad->nim); ?>" method="post">
          <input type="hidden" name="_method" value="delete">
          <?php echo e(csrf_field()); ?>

        <button type="submit" class="btn btn-danger marg float-right" value="delete">Ya, hapus</button>
        </form>

      </div>
    </div>
  </div>
</div>

<!-- Modal Hapus Terbitan-->
<div class="modal fade" id="HapusTerbitan" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <br>
        <h6>
          Apakah Anda yakin ingin menghapus terbitan ini?
        </h6>
        <br>
        <button type="button" class="btn btn-secondary marg float-right" data-dismiss="modal">Batal</button>

        <form action="/terbitan/<?php echo e($konten->id_konten); ?>" method="post">
          <input type="hidden" name="_method" value="delete">
          <?php echo e(csrf_field()); ?>

        <button type="submit" class="btn btn-danger rounded float-right" value="delete"><b>&nbsp;&nbsp;HAPUS&nbsp;&nbsp;</b></button>
        </form>
        
      </div>
    </div>
  </div>
</div>
