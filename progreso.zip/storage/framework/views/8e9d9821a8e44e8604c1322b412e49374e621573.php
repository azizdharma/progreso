<?php $__env->startSection('content'); ?>
<div class="row">
  <!-- start of mainbar -->
  <div class="col-md-8" id="mainBar">
    <div class="card">
      <div class="card-body">
        <div class="container">

          <br>
          <div class="row">
            <div class="col-7">
              <h3>Terbitan</h3>
            </div>
            <div class="col-5">
              <a role="button" href="terbitan/tambah" class="btn btn-success rounded float-right"><b class="putih">&nbsp;TAMBAH MANUAL&nbsp;</b></a>
            </div>
          </div>

          <br>
          <table class="table">
            <tbody>

              <?php $__currentLoopData = $kontens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $konten): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="row">
                  <td class="align-middle col-md-2">
                    <span class="timestamp">
                      <?php echo e((date("d M Y", strtotime($konten->tgl_konten)))); ?>

                    </span>
                  </td>
                  <td class="col-md-8">

                    <?php if($konten->nama_isu == 'null'): ?>
                      <span class="badge badge-danger"> <?php echo e($konten->nama_isu); ?></span>
                      <?php else: ?>
                        <span class="isu"> <?php echo e($konten->nama_isu); ?> /</span>
                    <?php endif; ?>

                    <?php if($konten->nama_rubrik == 'null'): ?>
                      <span class="badge badge-danger rubrik"> <?php echo e($konten->nama_rubrik); ?></span>
                      <?php else: ?>
                        <span class="isu"> <?php echo e($konten->nama_rubrik); ?> </span>
                    <?php endif; ?>

                    <a target="_blank" href="<?php echo e($konten->link); ?>" class="judul">
                      <h6><?php echo e($konten->judul_konten); ?></h6>
                    </a>

                    <span class="timestamp">Redaktur

                    <?php if($konten->nama == 'Admin'): ?>
                      <a href="/kamerad/<?php echo e($konten->nim); ?>" class="badge badge-danger putih alert-link rubrik">
                    <?php else: ?>
                      <a href="/kamerad/<?php echo e($konten->nim); ?>" class="alert-link">
                    <?php endif; ?>

                      <?php echo e($konten->panggilan); ?>

                      </a>
                    </span>
                  </td>
                  <td class="align-middle col-md-2">
                    <a role="button" class="btn btn-warning rounded kanan kolom edit" href="/terbitan/<?php echo e($konten->id_konten); ?>">
                      &nbsp;&nbsp;<img src="img/edit.png" alt="">&nbsp;&nbsp;
                    </a>
                  </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
          </table>

          <?php if(count($kontens) < 16): ?>
            <hr>
            <br>
            <center><a href="/terbitan-full" role="button" class="btn btn-success col-md-3"> <b class="putih"> SELENGKAPNYA </b></a></center>
            <br>
          <?php endif; ?>

        </div>
      </div>
    </div>
    <br>
  </div>
  <!-- end of mainbar -->
  <!--start of sidebar -->
  <div class="col-md-4" id="sideBar">
    <div class="card">
      <div class="card-body">
        <div class="container">
          <h5>Grafik Mingguan (2018)</h5>
          <div id="chartContainer1" style="height: 250px; max-width: 920px; margin: 0px auto;"></div>
        </div>
      </div>
    </div>
    <br>
    <div class="card">
      <div class="card-body">
        <div class="container">
          <h5>Rubrik Populer</h5>
          <div id="chartContainer2" style="height: 250px; width: 100%;"></div>
        </div>
      </div>
    </div>
    <br>
    <div class="card">
      <div class="card-body">
        <div class="container">
          <h5>Isu Terkini</h5>
          <div id="chartContainer3" style="height: 250px; width: 100%;"></div>
        </div>
      </div>
    </div>
    <br>
    <div class="card">
      <div class="card-body">
        <div class="container">
          <h5>Leaderboard Terbitan</h5>

          <?php echo $__env->make('widget.terbitan.popkamerad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        </div>
      </div>
    </div>
  </div>
  <!-- end of sidebar -->
</div>
<script>
window.onload = function () {

var chart1 = new CanvasJS.Chart("chartContainer1", {
	animationEnabled: true,
	axisX:{
		valueFormatString: "DD MMM",

    labelFontColor: "white",
		lineColor: "#d8d8d8"
	},
	axisY: {
		includeZero: false,
		gridColor: "#d8d8d8",
    labelFontColor: "#9e9e9e",
		lineColor: "#d8d8d8"
	},
	data: [{
		type: "line",
		color: "#ffb905",
    markerSize: 0,
		dataPoints: [

      <?php echo $__env->make('widget.terbitan.grafik', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		]
	}]
});
var chart2 = new CanvasJS.Chart("chartContainer2", {
  animationEnabled: true,
  axisX:{
    interval: 1,
    gridColor: "#d8d8d8",
    labelFontColor: "#9e9e9e",
    lineColor: "#d8d8d8"
  },
  axisY:{
    labelMaxWidth: -1,
    gridColor: "#d8d8d8",
    labelFontColor: "white",
    lineColor: "#d8d8d8"
  },
  data: [{
    type: "bar",
    name: "companies",
    color: "#27a9e6",
		toolTipContent: "<b>{label}:</b> {y} terbitan",
    dataPoints: [

      <?php echo $__env->make('widget.terbitan.poprubrik', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    ]
  }]
});
var chart3 = new CanvasJS.Chart("chartContainer3", {
	animationEnabled: true,
	data: [{
		type: "doughnut",
		startAngle: 180,
		//innerRadius: 60,
		// indexLabelFontSize: 2,
		indexLabel: "{label}",
		toolTipContent: "<b>{label}:</b> {y} (#percent%)",
		dataPoints: [

      <?php echo $__env->make('widget.terbitan.popisu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    ]
	}]
});

chart1.render();
chart2.render();
chart3.render();
}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>