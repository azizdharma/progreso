<?php $__currentLoopData = $widdiskusi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diskusi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  { y: <?php echo e($diskusi->jumlah); ?>, label:" <?php echo e($diskusi->jenis_diskusi); ?>" },
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
