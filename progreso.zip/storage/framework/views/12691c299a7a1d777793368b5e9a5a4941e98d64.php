<br>
<table class="table">
  <?php
    $n = 0;
  ?>
  <?php $__currentLoopData = $widkamerad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kamerad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($n < 1): ?>
      <tr>
        <td class="align-middle fit no-border">
          <a href="kamerad/<?php echo e($kamerad->nim); ?>">
          <img src="img/<?php echo e($kamerad->image); ?>" class="float-left img-circle" width="50px" height="50px">
          </a>
        </td>
        <td class="align-middle no-border">
          <a href="kamerad/<?php echo e($kamerad->nim); ?>">
          <span class="timestamp"><b><?php echo e($kamerad->panggilan); ?></b></span>
        </a>
        </td>
        <td class="align-middle no-border">
          <span class="timestamp"><b><?php echo e($kamerad->jumlah); ?> PX</b></span>
        </td>
      </tr>
      <?php
        $n++;
      ?>
      <?php else: ?>
        <tr>
          <td class="align-middle fit">
            <a href="kamerad/<?php echo e($kamerad->nim); ?>">
            <img src="img/<?php echo e($kamerad->image); ?>" class="float-left img-circle" width="50px" height="50px">
            </a>
          </td>
          <td class="align-middle">
            <a href="kamerad/<?php echo e($kamerad->nim); ?>">
            <span class="timestamp"><b><?php echo e($kamerad->panggilan); ?></b></span>
          </a>
          </td>
          <td class="align-middle">
            <span class="timestamp"><b><?php echo e($kamerad->jumlah); ?> PX</b></span>
          </td>
        </tr>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
