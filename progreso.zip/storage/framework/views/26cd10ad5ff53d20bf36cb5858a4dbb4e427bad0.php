<?php $__env->startSection('content'); ?>
<div class="row">
  <!-- start of mainbar -->
  <div class="col-md-8 col-sm-12" id="mainBar">
    <div class="card">
      <div class="card-body">
        <div class="container">
          <br>
          <div class="row">
            <div class="col-7">
              <h3>Diskusi</h3>
            </div>
            <div class="col-5">
              <a role="button" href="diskusi/tambah" class="btn btn-success rounded float-right"><b class="putih">&nbsp;TAMBAH&nbsp;</b></a>
            </div>
          </div>
          <br>

          <div class="row">
            <?php $__currentLoopData = $diskusis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diskusi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-md-6">
              <div class="card profilecards">

                <img class="card-img-top header-asoy bg-black rounded-top" src="img/bg-diskusi/<?php echo e($diskusi->jenis_diskusi); ?>.png">

                <div class="card-body dis-dis rounded-bottom">
                  <div class="row">
                    <div class="col-md-3 kanan">

                        <span class="bulan merah"><?php echo e((date("M", strtotime($diskusi->tgl_diskusi)))); ?></span>
                        <h5><?php echo e((date("d", strtotime($diskusi->tgl_diskusi)))); ?></h5>

                    </div>
                    <div class="col-md-9">
                      <span class="timestamp isu">
                        <?php if($diskusi->jenis_diskusi == 'KCM'): ?>
                          Kajian Cinta Menulis
                        <?php elseif($diskusi->jenis_diskusi == 'KCB'): ?>
                          Kajian Cinta Baca
                        <?php elseif($diskusi->jenis_diskusi == 'KSF'): ?>
                          Kesengsem Foto
                        <?php elseif($diskusi->jenis_diskusi == 'KJM'): ?>
                          Kajian Jumat Malam
                        <?php elseif($diskusi->jenis_diskusi == 'ART'): ?>
                          Diskusi Artistik
                        <?php elseif($diskusi->jenis_diskusi == 'MJL'): ?>
                          Presentasi Tema Majalah
                        <?php elseif($diskusi->jenis_diskusi == 'BKU'): ?>
                          Presentasi Tema Buku
                        <?php elseif($diskusi->jenis_diskusi == 'JKS'): ?>
                          JK Share
                          <?php else: ?>
                            Diskusi Lainnya
                        <?php endif; ?>
                      </span>

                      <a href="/diskusi/<?php echo e($diskusi->kode_diskusi); ?>" class="judul">
                        <h6><?php echo e($diskusi->judul_diskusi); ?></h6>
                      </a>

                      <span class="timestamp">Pemantik
                        <?php if($diskusi->nama == 'Admin'): ?>
                          <a href="/kamerad/<?php echo e($diskusi->nim); ?>" class="badge badge-danger putih alert-link rubrik">
                        <?php else: ?>
                          <a href="/kamerad/<?php echo e($diskusi->nim); ?>" class="alert-link">
                        <?php endif; ?>
                          <?php echo e($diskusi->panggilan); ?>

                          </a>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>

          <?php if(count($diskusis) < 16): ?>
            <br>
            <center><a href="/diskusi-full" role="button" name="button" class="btn btn-success col-md-3"> <b class="putih"> SELENGKAPNYA </b></a></center>
            <br>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <br>
  </div>
  <!-- end of mainbar -->
  <!--start of sidebar -->
  <div class="col-md-4 col-sm-12" id="sideBar">
    <div class="card">
      <div class="card-body">
        <div class="container">
          <h5>Grafik Bulanan</h5>
          <div id="chartContainer1" style="height: 250px; max-width: 920px; margin: 0px auto;"></div>
        </div>
      </div>
    </div>
    <br>
    <div class="card">
      <div class="card-body">
        <div class="container">
          <h5>Diskusi Populer</h5>
          <div id="chartContainer2" style="height: 250px; width: 100%;"></div>
        </div>
      </div>
    </div>
    <br>
    <div class="card">
      <div class="card-body">
        <div class="container">
          <h5>Leaderboard Terbitan</h5>
          <?php echo $__env->make('widget.diskusi.poppemantik', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
      </div>
    </div>
    <br>
  </div>
  <!-- end of sidebar -->
</div>
<script>
window.onload = function () {

var chart1 = new CanvasJS.Chart("chartContainer1", {
	animationEnabled: true,
	axisX:{
    valueFormatString: "DD MMM",

    labelFontColor: "white",
		lineColor: "#d8d8d8"
	},
	axisY: {
		includeZero: false,
		gridColor: "#d8d8d8",
    labelFontColor: "#9e9e9e",
		lineColor: "#d8d8d8"
	},
	data: [{
		type: "line",
		color: "#ffb905",
    markerSize: 0,
		dataPoints: [

      <?php echo $__env->make('widget.diskusi.grafikdiskusi', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		]
	}]
});
var chart2 = new CanvasJS.Chart("chartContainer2", {
  animationEnabled: true,
  axisX:{
    interval: 1,
    gridColor: "#d8d8d8",
    labelFontColor: "#9e9e9e",
    lineColor: "#d8d8d8"
  },
  axisY:{
    labelMaxWidth: -1,
    gridColor: "#d8d8d8",
    labelFontColor: "white",
    lineColor: "#d8d8d8"
  },
  data: [{
    type: "bar",
    name: "companies",
    color: "#27a9e6",
		toolTipContent: "<b>{label}:</b> {y} terbitan",
    dataPoints: [

      <?php echo $__env->make('widget.diskusi.popdiskusi', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    ]
  }]
});
var chart3 = new CanvasJS.Chart("chartContainer3", {
	animationEnabled: true,
	data: [{
		type: "doughnut",
		startAngle: 180,
		//innerRadius: 60,
		// indexLabelFontSize: 2,
		indexLabel: "{label}",
		toolTipContent: "<b>{label}:</b> {y} (#percent%)",
		dataPoints: [



    ]
	}]
});

chart1.render();
chart2.render();
chart3.render();
}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>