<?php

Route::get('/', function () {
    return view('beranda');
});

Route::get('/terbitan', 'TerbitanController@index');
Route::get('/terbitan-full', 'TerbitanController@full');
Route::get('/terbitan/tambah', 'TerbitanController@create');
Route::post('/terbitan', 'TerbitanController@store');
Route::get('/terbitan/{idTerbitan}', 'TerbitanController@edit');
Route::put('/terbitan/{idTerbitan}', 'TerbitanController@update');
Route::delete('/terbitan/{idTerbitan}', 'TerbitanController@destroy');

Route::get('/kamerad', 'KameradController@index');
Route::get('/post', 'KameradController@post');
Route::get('/alumni', 'KameradController@alumni');
Route::get('/kamerad/tambah', 'KameradController@create');
Route::get('/kamerad/{nim}', 'KameradController@show');
Route::post('/kamerad', 'KameradController@store');
Route::get('/kamerad/{nim}/edit', 'KameradController@edit');
Route::put('/kamerad/{nim}', 'KameradController@update');
Route::delete('/kamerad/{nim}', 'KameradController@destroy');

Route::get('/diskusi', 'DiskusiController@index');
Route::get('/diskusi-full', 'DiskusiController@full');
Route::get('/diskusi/tambah', 'DiskusiController@create');
Route::post('/diskusi', 'DiskusiController@store');
Route::get('/diskusi/{idDiskusi}', 'DiskusiController@edit');
Route::put('/diskusi/{idDiskusi}', 'DiskusiController@update');
Route::delete('/diskusi/{idDiskusi}', 'DiskusiController@destroy');

Route::get('/aktivitas', 'AktivitasController@index');
Route::get('/aktivitas-full', 'AktivitasController@full');

Route::get('/manifesto', 'SettingController@manifesto');
